package com.hospitalarchive.hospitalarchivebackend;

import com.hospitalarchive.hospitalarchivebackend.model.ArchiveDocument;
import com.hospitalarchive.hospitalarchivebackend.model.Patient;
import com.hospitalarchive.hospitalarchivebackend.model.Department;
import com.hospitalarchive.hospitalarchivebackend.model.DocumentType;
import com.hospitalarchive.hospitalarchivebackend.repository.DocumentRepository;
import com.hospitalarchive.hospitalarchivebackend.repository.PatientRepository;
import com.hospitalarchive.hospitalarchivebackend.repository.DepartmentRepository;
import com.hospitalarchive.hospitalarchivebackend.repository.DocumentTypeRepository;
import com.hospitalarchive.hospitalarchivebackend.service.DocumentService;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DocumentServiceTests {

    private final DocumentRepository documentRepository =
            mock(DocumentRepository.class);

    private final PatientRepository patientRepository =
            mock(PatientRepository.class);

    private final DepartmentRepository departmentRepository =
            mock(DepartmentRepository.class);

    private final DocumentTypeRepository documentTypeRepository =
            mock(DocumentTypeRepository.class);

    private final DocumentService documentService = new DocumentService(
            documentRepository,
            patientRepository,
            departmentRepository,
            documentTypeRepository
    );

    // Create valid sample document details
    private ArchiveDocument createValidDocument() {
        ArchiveDocument document = new ArchiveDocument();
        document.setPatientID(1);
        document.setDocumentTypeID(1);
        document.setDepartmentID(1);
        document.setUploadedBy(1);
        document.setDocumentTitle("Laboratory Report");
        document.setFileName("report.pdf");
        document.setFilePath("test-files/report.pdf");
        document.setFileFormat("pdf");
        return document;
    }

    // Make all related records available for successful saves
    private void setUpExistingRecords() {
        when(patientRepository.findById(1))
                .thenReturn(Optional.of(new Patient()));

        when(departmentRepository.findById(1))
                .thenReturn(Optional.of(new Department()));

        when(documentTypeRepository.findById(1))
                .thenReturn(Optional.of(new DocumentType()));
    }

    @Test
    void saveDocumentAcceptsValidDocumentAndSetsMissingDate() {

        ArchiveDocument document = createValidDocument();
        setUpExistingRecords();

        when(documentRepository.save(document)).thenReturn(document);

        ArchiveDocument savedDocument =
                documentService.saveDocument(document);

        assertSame(document, savedDocument);
        assertNotNull(document.getUploadDate());
        verify(documentRepository).save(document);
    }

    @Test
    void saveDocumentPreservesExistingUploadDate() {

        ArchiveDocument document = createValidDocument();
        LocalDateTime originalDate =
                LocalDateTime.of(2026, 8, 1, 10, 30);

        document.setUploadDate(originalDate);
        setUpExistingRecords();

        when(documentRepository.save(document)).thenReturn(document);

        documentService.saveDocument(document);

        assertEquals(originalDate, document.getUploadDate());
        verify(documentRepository).save(document);
    }

    @Test
    void saveDocumentRejectsNullDocument() {

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> documentService.saveDocument(null)
        );

        assertEquals("Document cannot be null.", exception.getMessage());
        verifyNoInteractions(documentRepository);
    }

    @Test
    void saveDocumentRejectsBlankTitle() {

        ArchiveDocument document = createValidDocument();
        document.setDocumentTitle("   ");

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> documentService.saveDocument(document)
        );

        assertEquals("Document title is required.", exception.getMessage());
        verifyNoInteractions(documentRepository);
    }

    @Test
    void saveDocumentRejectsInvalidPatientId() {

        ArchiveDocument document = createValidDocument();
        document.setPatientID(0);

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> documentService.saveDocument(document)
        );

        assertEquals(
                "A positive patient ID is required.",
                exception.getMessage()
        );
        verifyNoInteractions(documentRepository);
    }

    @Test
    void saveDocumentRejectsBlankFilePath() {

        ArchiveDocument document = createValidDocument();
        document.setFilePath("   ");

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> documentService.saveDocument(document)
        );

        assertEquals("File path is required.", exception.getMessage());
        verifyNoInteractions(documentRepository);
    }

    @Test
    void saveDocumentRejectsMissingPatient() {

        ArchiveDocument document = createValidDocument();

        when(patientRepository.findById(1))
                .thenReturn(Optional.empty());

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> documentService.saveDocument(document)
        );

        assertEquals("Patient does not exist.", exception.getMessage());
        verifyNoInteractions(documentRepository);
    }

    @Test
    void saveDocumentRejectsMissingDepartment() {

        ArchiveDocument document = createValidDocument();

        when(patientRepository.findById(1))
                .thenReturn(Optional.of(new Patient()));

        when(departmentRepository.findById(1))
                .thenReturn(Optional.empty());

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> documentService.saveDocument(document)
        );

        assertEquals("Department does not exist.", exception.getMessage());
        verifyNoInteractions(documentRepository);
    }

    @Test
    void saveDocumentRejectsMissingDocumentType() {

        ArchiveDocument document = createValidDocument();

        when(patientRepository.findById(1))
                .thenReturn(Optional.of(new Patient()));

        when(departmentRepository.findById(1))
                .thenReturn(Optional.of(new Department()));

        when(documentTypeRepository.findById(1))
                .thenReturn(Optional.empty());

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> documentService.saveDocument(document)
        );

        assertEquals("Document type does not exist.", exception.getMessage());
        verifyNoInteractions(documentRepository);
    }
}
