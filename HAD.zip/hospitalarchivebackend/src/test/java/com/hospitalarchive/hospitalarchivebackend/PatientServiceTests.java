package com.hospitalarchive.hospitalarchivebackend;

import com.hospitalarchive.hospitalarchivebackend.model.Patient;
import com.hospitalarchive.hospitalarchivebackend.model.ArchiveDocument;
import com.hospitalarchive.hospitalarchivebackend.repository.PatientRepository;
import com.hospitalarchive.hospitalarchivebackend.repository.DocumentRepository;
import com.hospitalarchive.hospitalarchivebackend.service.PatientService;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PatientServiceTests {

    private final PatientRepository patientRepository =
            mock(PatientRepository.class);

    private final DocumentRepository documentRepository =
            mock(DocumentRepository.class);

    private final PatientService patientService = new PatientService(
            patientRepository,
            documentRepository
    );

    // Create valid sample data for each test
    private Patient createValidPatient() {
        Patient patient = new Patient();
        patient.setHospitalNumber("H001");
        patient.setFirstName("Alex");
        patient.setLastName("Smith");
        return patient;
    }

    @Test
    void savePatientAcceptsValidPatient() {

        Patient patient = createValidPatient();

        when(patientRepository.save(patient)).thenReturn(patient);

        Patient savedPatient = patientService.savePatient(patient);

        assertSame(patient, savedPatient);
        verify(patientRepository).save(patient);
    }

    @Test
    void savePatientRejectsNullPatient() {

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> patientService.savePatient(null)
        );

        assertEquals("Patient cannot be null.", exception.getMessage());
        verifyNoInteractions(patientRepository);
    }

    @Test
    void savePatientRejectsBlankHospitalNumber() {

        Patient patient = createValidPatient();
        patient.setHospitalNumber("   ");

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> patientService.savePatient(patient)
        );

        assertEquals("Hospital number is required.", exception.getMessage());
        verifyNoInteractions(patientRepository);
    }

    @Test
    void savePatientRejectsBlankFirstName() {

        Patient patient = createValidPatient();
        patient.setFirstName("   ");

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> patientService.savePatient(patient)
        );

        assertEquals("First name is required.", exception.getMessage());
        verifyNoInteractions(patientRepository);
    }

    @Test
    void savePatientRejectsBlankLastName() {

        Patient patient = createValidPatient();
        patient.setLastName("   ");

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> patientService.savePatient(patient)
        );

        assertEquals("Last name is required.", exception.getMessage());
        verifyNoInteractions(patientRepository);
    }

    @Test
    void deletePatientRejectsPatientWithLinkedDocuments() {

        ArchiveDocument document = new ArchiveDocument();
        document.setDocumentID(10);
        document.setPatientID(1);

        when(documentRepository.findByPatientID(1))
                .thenReturn(List.of(document));

        IllegalStateException exception = assertThrows(
                IllegalStateException.class,
                () -> patientService.deletePatient(1)
        );

        assertEquals(
                "Cannot delete a patient who has linked documents.",
                exception.getMessage()
        );

        verifyNoInteractions(patientRepository);
    }

    @Test
    void deletePatientAllowsPatientWithoutLinkedDocuments() {

        when(documentRepository.findByPatientID(1))
                .thenReturn(List.of());

        patientService.deletePatient(1);

        verify(patientRepository).deleteById(1);
    }
}