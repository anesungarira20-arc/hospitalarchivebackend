package com.hospitalarchive.hospitalarchivebackend;

import com.hospitalarchive.hospitalarchivebackend.model.User;
import com.hospitalarchive.hospitalarchivebackend.repository.UserRepository;
import com.hospitalarchive.hospitalarchivebackend.service.UserService;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserServiceTests {

    private final UserRepository userRepository =
            mock(UserRepository.class);

    private final PasswordEncoder passwordEncoder =
            new BCryptPasswordEncoder();

    private final UserService userService = new UserService(
            userRepository,
            passwordEncoder
    );

    // Create valid sample user details
    private User createValidUser() {
        User user = new User();
        user.setUsername("archive_staff");
        user.setPassword("test-password");
        return user;
    }

    @Test
    void saveUserStoresHashedPasswordAndPreservesInput() {

        User user = createValidUser();

        when(userRepository.save(any(User.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        User savedUser = userService.saveUser(user);

        ArgumentCaptor<User> captor = ArgumentCaptor.forClass(User.class);
        verify(userRepository).save(captor.capture());

        User storedUser = captor.getValue();

        assertNotSame(user, storedUser);
        assertSame(storedUser, savedUser);
        assertEquals("archive_staff", storedUser.getUsername());

        assertNotEquals("test-password", storedUser.getPassword());
        assertTrue(passwordEncoder.matches(
                "test-password",
                storedUser.getPassword()
        ));
        assertFalse(passwordEncoder.matches(
                "wrong-password",
                storedUser.getPassword()
        ));

        assertEquals("test-password", user.getPassword());
    }

    @Test
    void saveUserRejectsNullUser() {

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> userService.saveUser(null)
        );

        assertEquals("User cannot be null.", exception.getMessage());
        verifyNoInteractions(userRepository);
    }

    @Test
    void saveUserRejectsBlankUsername() {

        User user = createValidUser();
        user.setUsername("   ");

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> userService.saveUser(user)
        );

        assertEquals("Username is required.", exception.getMessage());
        verifyNoInteractions(userRepository);
    }

    @Test
    void saveUserRejectsBlankPassword() {

        User user = createValidUser();
        user.setPassword("   ");

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> userService.saveUser(user)
        );

        assertEquals("Password is required.", exception.getMessage());
        verifyNoInteractions(userRepository);
    }

    @Test
    void saveUserRejectsExistingUserId() {

        User user = createValidUser();
        user.setUserID(1);

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> userService.saveUser(user)
        );

        assertEquals(
                "User ID must be zero when creating a user.",
                exception.getMessage()
        );
        verifyNoInteractions(userRepository);
    }

    @Test
    void saveUserRejectsDuplicateUsername() {

        User user = createValidUser();

        when(userRepository.existsByUsername("archive_staff"))
                .thenReturn(true);

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> userService.saveUser(user)
        );

        assertEquals(
                "Username already belongs to another user.",
                exception.getMessage()
        );
        verify(userRepository, never()).save(any(User.class));
    }

    @Test
    void saveUserRejectsPasswordOver72Bytes() {

        User user = createValidUser();
        user.setPassword("a".repeat(73));

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> userService.saveUser(user)
        );

        assertEquals(
                "Password must not exceed 72 UTF-8 bytes.",
                exception.getMessage()
        );
        verifyNoInteractions(userRepository);
    }

    @Test
    void saveUserChecksPasswordBytesRatherThanCharacterCount() {

        User user = createValidUser();

        // Each character uses two bytes in UTF-8
        user.setPassword("\u00E9".repeat(37));

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> userService.saveUser(user)
        );

        assertEquals(
                "Password must not exceed 72 UTF-8 bytes.",
                exception.getMessage()
        );
        verifyNoInteractions(userRepository);
    }
}