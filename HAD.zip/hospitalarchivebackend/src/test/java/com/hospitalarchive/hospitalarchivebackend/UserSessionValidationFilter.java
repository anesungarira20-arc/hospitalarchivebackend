package com.hospitalarchive.hospitalarchivebackend;

import com.hospitalarchive.hospitalarchivebackend.config.UserSessionValidationFilter;
import com.hospitalarchive.hospitalarchivebackend.model.User;
import com.hospitalarchive.hospitalarchivebackend.repository.UserRepository;

import jakarta.servlet.FilterChain;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserSessionValidationFilterTests {

    private final UserRepository userRepository =
            mock(UserRepository.class);

    private final UserSessionValidationFilter filter =
            new UserSessionValidationFilter(userRepository);

    @AfterEach
    void clearSecurityContext() {
        SecurityContextHolder.clearContext();
    }

    private void logInWithRole(String role) {
        SecurityContextHolder.getContext().setAuthentication(
                UsernamePasswordAuthenticationToken.authenticated(
                        "test_staff",
                        null,
                        List.of(
                                new SimpleGrantedAuthority("ROLE_" + role),
                                new SimpleGrantedAuthority("FACTOR_PASSWORD")
                        )
                )
        );

    }

    private User createUser(String role) {
        User user = new User();
        user.setUsername("test_staff");
        user.setRole(role);
        return user;
    }

    @Test
    void matchingRoleAllowsRequest() throws Exception {

        logInWithRole("READ_ONLY");

        when(userRepository.findByUsername("test_staff"))
                .thenReturn(Optional.of(createUser("READ_ONLY")));

        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();
        FilterChain chain = mock(FilterChain.class);

        filter.doFilter(request, response, chain);

        verify(chain).doFilter(request, response);
        assertNotNull(
                SecurityContextHolder.getContext().getAuthentication()
        );
    }

    @Test
    void changedRoleEndsSessionAndBlocksRequest() throws Exception {

        logInWithRole("ADMIN");

        when(userRepository.findByUsername("test_staff"))
                .thenReturn(Optional.of(createUser("READ_ONLY")));

        MockHttpSession session = new MockHttpSession();
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setSession(session);

        MockHttpServletResponse response = new MockHttpServletResponse();
        FilterChain chain = mock(FilterChain.class);

        filter.doFilter(request, response, chain);

        assertEquals(401, response.getStatus());
        assertTrue(session.isInvalid());
        assertNull(
                SecurityContextHolder.getContext().getAuthentication()
        );
        verifyNoInteractions(chain);
    }

    @Test
    void deletedUserEndsSessionAndBlocksRequest() throws Exception {

        logInWithRole("READ_ONLY");

        when(userRepository.findByUsername("test_staff"))
                .thenReturn(Optional.empty());

        MockHttpSession session = new MockHttpSession();
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setSession(session);

        MockHttpServletResponse response = new MockHttpServletResponse();
        FilterChain chain = mock(FilterChain.class);

        filter.doFilter(request, response, chain);

        assertEquals(401, response.getStatus());
        assertTrue(session.isInvalid());
        assertNull(
                SecurityContextHolder.getContext().getAuthentication()
        );
        verifyNoInteractions(chain);
    }

    @Test
    void requestWithoutLoginContinuesToSecurityChecks() throws Exception {

        SecurityContextHolder.clearContext();

        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();
        FilterChain chain = mock(FilterChain.class);

        filter.doFilter(request, response, chain);

        verify(chain).doFilter(request, response);
        verifyNoInteractions(userRepository);
    }
}
