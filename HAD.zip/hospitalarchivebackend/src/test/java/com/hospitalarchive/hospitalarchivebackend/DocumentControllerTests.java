package com.hospitalarchive.hospitalarchivebackend;

import com.hospitalarchive.hospitalarchivebackend.controller.DocumentController;
import com.hospitalarchive.hospitalarchivebackend.model.ArchiveDocument;
import com.hospitalarchive.hospitalarchivebackend.model.Auditlog;
import com.hospitalarchive.hospitalarchivebackend.model.User;
import com.hospitalarchive.hospitalarchivebackend.service.AuditLogService;
import com.hospitalarchive.hospitalarchivebackend.service.DocumentService;
import com.hospitalarchive.hospitalarchivebackend.service.UserService;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InOrder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.server.ResponseStatusException;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DocumentControllerTests {

    private final DocumentService documentService =
            mock(DocumentService.class);

    private final UserService userService =
            mock(UserService.class);

    private final AuditLogService auditLogService =
            mock(AuditLogService.class);

    private final DocumentController controller =
            new DocumentController(
                    documentService,
                    userService,
                    auditLogService
            );

    private Principal setUpLoggedInUser(int userID) {
        User user = new User();
        user.setUserID(userID);
        user.setUsername("test_user");

        when(userService.getUserByUsername("test_user"))
                .thenReturn(Optional.of(user));

        return () -> "test_user";
    }

    @Test
    void createUsesLoggedInUploaderAndRecordsAction() {

        Principal principal = setUpLoggedInUser(7);

        ArchiveDocument document = new ArchiveDocument();
        document.setUploadedBy(999);

        when(documentService.saveDocument(any(ArchiveDocument.class)))
                .thenAnswer(invocation -> {
                    ArchiveDocument saved = invocation.getArgument(0);
                    saved.setDocumentID(1);
                    return saved;
                });

        ResponseEntity<ArchiveDocument> response =
                controller.createDocument(document, principal);

        ArgumentCaptor<Auditlog> logCaptor =
                ArgumentCaptor.forClass(Auditlog.class);

        InOrder order = inOrder(documentService, auditLogService);
        order.verify(documentService).saveDocument(document);
        order.verify(auditLogService).saveAuditLog(logCaptor.capture());

        assertEquals(201, response.getStatusCode().value());
        assertNotNull(response.getBody());
        assertEquals(7, response.getBody().getUploadedBy());

        Auditlog log = logCaptor.getValue();
        assertEquals(7, log.getUserID());
        assertEquals(Integer.valueOf(1), log.getDocumentID());
        assertEquals("CREATE", log.getAction());
        assertEquals("Created document details.", log.getActionDescription());
    }

    @Test
    void createRejectsMissingLoginWithoutLogging() {

        ResponseStatusException exception = assertThrows(
                ResponseStatusException.class,
                () -> controller.createDocument(new ArchiveDocument(), null)
        );

        assertEquals(401, exception.getStatusCode().value());
        verifyNoInteractions(documentService, userService, auditLogService);
    }

    @Test
    void createRejectsMissingUserRecordWithoutLogging() {

        when(userService.getUserByUsername("missing_user"))
                .thenReturn(Optional.empty());

        Principal principal = () -> "missing_user";

        ResponseStatusException exception = assertThrows(
                ResponseStatusException.class,
                () -> controller.createDocument(
                        new ArchiveDocument(),
                        principal
                )
        );

        assertEquals(401, exception.getStatusCode().value());
        verifyNoInteractions(documentService, auditLogService);
    }

    @Test
    void failedCreateDoesNotRecordSuccess() {

        Principal principal = setUpLoggedInUser(7);

        when(documentService.saveDocument(any(ArchiveDocument.class)))
                .thenThrow(new IllegalArgumentException(
                        "Patient does not exist."
                ));

        ResponseStatusException exception = assertThrows(
                ResponseStatusException.class,
                () -> controller.createDocument(
                        new ArchiveDocument(),
                        principal
                )
        );

        assertEquals(400, exception.getStatusCode().value());
        verifyNoInteractions(auditLogService);
    }

    @Test
    void updatePreservesUploaderAndLogsCurrentActor() {

        Principal principal = setUpLoggedInUser(8);
        LocalDateTime originalDate =
                LocalDateTime.of(2026, 9, 1, 10, 0);

        ArchiveDocument existing = new ArchiveDocument();
        existing.setDocumentID(1);
        existing.setUploadedBy(7);
        existing.setUploadDate(originalDate);

        when(documentService.getDocumentById(1))
                .thenReturn(Optional.of(existing));

        ArchiveDocument update = new ArchiveDocument();
        update.setDocumentID(1);
        update.setUploadedBy(999);
        update.setUploadDate(originalDate.plusDays(1));

        when(documentService.saveDocument(any(ArchiveDocument.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        ResponseEntity<ArchiveDocument> response =
                controller.updateDocument(1, update, principal);

        ArgumentCaptor<Auditlog> logCaptor =
                ArgumentCaptor.forClass(Auditlog.class);

        InOrder order = inOrder(documentService, auditLogService);
        order.verify(documentService).saveDocument(update);
        order.verify(auditLogService).saveAuditLog(logCaptor.capture());

        assertEquals(200, response.getStatusCode().value());
        assertEquals(7, update.getUploadedBy());
        assertEquals(originalDate, update.getUploadDate());

        assertEquals(8, logCaptor.getValue().getUserID());
        assertEquals("UPDATE", logCaptor.getValue().getAction());
        assertEquals(
                Integer.valueOf(1),
                logCaptor.getValue().getDocumentID()
        );
    }

    @Test
    void deleteRecordsCurrentActorAfterDeletion() {

        Principal principal = setUpLoggedInUser(8);

        ArchiveDocument existing = new ArchiveDocument();
        existing.setDocumentID(1);
        existing.setUploadedBy(7);

        when(documentService.getDocumentById(1))
                .thenReturn(Optional.of(existing));

        ResponseEntity<Void> response =
                controller.deleteDocument(1, principal);

        ArgumentCaptor<Auditlog> logCaptor =
                ArgumentCaptor.forClass(Auditlog.class);

        InOrder order = inOrder(documentService, auditLogService);
        order.verify(documentService).deleteDocument(1);
        order.verify(auditLogService).saveAuditLog(logCaptor.capture());

        assertEquals(204, response.getStatusCode().value());
        assertEquals(8, logCaptor.getValue().getUserID());
        assertEquals("DELETE", logCaptor.getValue().getAction());
        assertEquals(
                Integer.valueOf(1),
                logCaptor.getValue().getDocumentID()
        );
    }

    @Test
    void missingDocumentIsNotDeletedOrLogged() {

        Principal principal = setUpLoggedInUser(8);

        when(documentService.getDocumentById(99))
                .thenReturn(Optional.empty());

        ResponseEntity<Void> response =
                controller.deleteDocument(99, principal);

        assertEquals(404, response.getStatusCode().value());
        verify(documentService, never()).deleteDocument(anyInt());
        verifyNoInteractions(auditLogService);
    }
}
