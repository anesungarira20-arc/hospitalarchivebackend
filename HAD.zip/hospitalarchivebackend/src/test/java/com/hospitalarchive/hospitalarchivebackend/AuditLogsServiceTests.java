package com.hospitalarchive.hospitalarchivebackend;

import com.hospitalarchive.hospitalarchivebackend.model.Auditlog;
import com.hospitalarchive.hospitalarchivebackend.repository.AuditLogRepository;
import com.hospitalarchive.hospitalarchivebackend.service.AuditLogService;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AuditLogServiceTests {

    private final AuditLogRepository auditLogRepository =
            mock(AuditLogRepository.class);

    private final AuditLogService auditLogService =
            new AuditLogService(auditLogRepository);

    // Create valid sample log details
    private Auditlog createValidAuditLog() {
        Auditlog auditLog = new Auditlog();
        auditLog.setUserID(1);
        auditLog.setDocumentID(1);
        auditLog.setAction("VIEW");
        auditLog.setActionDescription("Viewed a laboratory report.");
        return auditLog;
    }

    @Test
    void saveAuditLogAcceptsValidLogAndSetsMissingDate() {

        Auditlog auditLog = createValidAuditLog();

        when(auditLogRepository.save(auditLog)).thenReturn(auditLog);

        Auditlog savedLog = auditLogService.saveAuditLog(auditLog);

        assertSame(auditLog, savedLog);
        assertNotNull(auditLog.getActionDate());
        verify(auditLogRepository).save(auditLog);
    }

    @Test
    void saveAuditLogPreservesExistingDate() {

        Auditlog auditLog = createValidAuditLog();
        LocalDateTime originalDate =
                LocalDateTime.of(2026, 8, 1, 10, 30);

        auditLog.setActionDate(originalDate);

        when(auditLogRepository.save(auditLog)).thenReturn(auditLog);

        auditLogService.saveAuditLog(auditLog);

        assertEquals(originalDate, auditLog.getActionDate());
        verify(auditLogRepository).save(auditLog);
    }

    @Test
    void saveAuditLogAcceptsMissingDocumentId() {

        Auditlog auditLog = createValidAuditLog();
        auditLog.setDocumentID(null);
        auditLog.setAction("LOGIN");
        auditLog.setActionDescription("User logged in.");

        when(auditLogRepository.save(auditLog)).thenReturn(auditLog);

        Auditlog savedLog = auditLogService.saveAuditLog(auditLog);

        assertSame(auditLog, savedLog);
        assertNull(savedLog.getDocumentID());
        verify(auditLogRepository).save(auditLog);
    }

    @Test
    void saveAuditLogRejectsNullLog() {

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> auditLogService.saveAuditLog(null)
        );

        assertEquals("Audit log cannot be null.", exception.getMessage());
        verifyNoInteractions(auditLogRepository);
    }

    @Test
    void saveAuditLogRejectsInvalidUserId() {

        Auditlog auditLog = createValidAuditLog();
        auditLog.setUserID(0);

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> auditLogService.saveAuditLog(auditLog)
        );

        assertEquals("A positive user ID is required.", exception.getMessage());
        verifyNoInteractions(auditLogRepository);
    }

    @Test
    void saveAuditLogRejectsInvalidDocumentId() {

        Auditlog auditLog = createValidAuditLog();
        auditLog.setDocumentID(0);

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> auditLogService.saveAuditLog(auditLog)
        );

        assertEquals("Document ID must be positive.", exception.getMessage());
        verifyNoInteractions(auditLogRepository);
    }

    @Test
    void saveAuditLogRejectsBlankAction() {

        Auditlog auditLog = createValidAuditLog();
        auditLog.setAction("   ");

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> auditLogService.saveAuditLog(auditLog)
        );

        assertEquals("Action is required.", exception.getMessage());
        verifyNoInteractions(auditLogRepository);
    }

    @Test
    void saveAuditLogRejectsBlankDescription() {

        Auditlog auditLog = createValidAuditLog();
        auditLog.setActionDescription("   ");

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> auditLogService.saveAuditLog(auditLog)
        );

        assertEquals(
                "Action description is required.",
                exception.getMessage()
        );
        verifyNoInteractions(auditLogRepository);
    }
}
