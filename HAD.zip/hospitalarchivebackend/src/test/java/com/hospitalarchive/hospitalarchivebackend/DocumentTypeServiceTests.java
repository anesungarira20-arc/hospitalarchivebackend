package com.hospitalarchive.hospitalarchivebackend;

import com.hospitalarchive.hospitalarchivebackend.model.DocumentType;
import com.hospitalarchive.hospitalarchivebackend.model.ArchiveDocument;
import com.hospitalarchive.hospitalarchivebackend.repository.DocumentTypeRepository;
import com.hospitalarchive.hospitalarchivebackend.repository.DocumentRepository;
import com.hospitalarchive.hospitalarchivebackend.service.DocumentTypeService;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DocumentTypeServiceTests {

    private final DocumentTypeRepository documentTypeRepository =
            mock(DocumentTypeRepository.class);

    private final DocumentRepository documentRepository =
            mock(DocumentRepository.class);

    private final DocumentTypeService documentTypeService =
            new DocumentTypeService(
                    documentTypeRepository,
                    documentRepository
            );

    @Test
    void saveDocumentTypeAcceptsValidDocumentType() {

        DocumentType documentType = new DocumentType();
        documentType.setDocumentTypeName("Laboratory Report");

        when(documentTypeRepository.save(documentType))
                .thenReturn(documentType);

        DocumentType savedDocumentType =
                documentTypeService.saveDocumentType(documentType);

        assertSame(documentType, savedDocumentType);
        verify(documentTypeRepository).save(documentType);
    }

    @Test
    void saveDocumentTypeRejectsNullDocumentType() {

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> documentTypeService.saveDocumentType(null)
        );

        assertEquals("Document type cannot be null.", exception.getMessage());
        verifyNoInteractions(documentTypeRepository);
    }

    @Test
    void saveDocumentTypeRejectsBlankName() {

        DocumentType documentType = new DocumentType();
        documentType.setDocumentTypeName("   ");

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> documentTypeService.saveDocumentType(documentType)
        );

        assertEquals("Document type name is required.", exception.getMessage());
        verifyNoInteractions(documentTypeRepository);
    }

    @Test
    void saveDocumentTypeRejectsNullName() {

        DocumentType documentType = new DocumentType();

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> documentTypeService.saveDocumentType(documentType)
        );

        assertEquals("Document type name is required.", exception.getMessage());
        verifyNoInteractions(documentTypeRepository);
    }

    @Test
    void deleteDocumentTypeRejectsTypeWithLinkedDocuments() {

        ArchiveDocument document = new ArchiveDocument();
        document.setDocumentID(10);
        document.setDocumentTypeID(1);

        when(documentRepository.findByDocumentTypeID(1))
                .thenReturn(List.of(document));

        IllegalStateException exception = assertThrows(
                IllegalStateException.class,
                () -> documentTypeService.deleteDocumentType(1)
        );

        assertEquals(
                "Cannot delete a document type that has linked documents.",
                exception.getMessage()
        );

        verifyNoInteractions(documentTypeRepository);
    }

    @Test
    void deleteDocumentTypeAllowsTypeWithoutLinkedDocuments() {

        when(documentRepository.findByDocumentTypeID(1))
                .thenReturn(List.of());

        documentTypeService.deleteDocumentType(1);

        verify(documentTypeRepository).deleteById(1);
    }
}