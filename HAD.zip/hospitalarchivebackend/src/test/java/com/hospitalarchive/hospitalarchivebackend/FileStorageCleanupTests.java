package com.hospitalarchive.hospitalarchivebackend;

import com.hospitalarchive.hospitalarchivebackend.service.FileStorageService;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.mock.web.MockMultipartFile;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class FileStorageCleanupTests {

    @TempDir
    Path temporaryDirectory;

    @Test
    void deletesGeneratedFile() throws Exception {

        FileStorageService service =
                new FileStorageService(temporaryDirectory.toString());

        MockMultipartFile file = new MockMultipartFile(
                "file",
                "report.pdf",
                "application/pdf",
                "%PDF-1.4\nTest\n%%EOF"
                        .getBytes(StandardCharsets.US_ASCII)
        );

        String storedName = service.storePdf(file);
        Path storedPath = temporaryDirectory.resolve(storedName);

        assertTrue(Files.exists(storedPath));

        service.deleteStoredFile(storedName);

        assertFalse(Files.exists(storedPath));
    }

    @Test
    void missingGeneratedFileDoesNotCauseFailure() {

        FileStorageService service =
                new FileStorageService(temporaryDirectory.toString());

        assertDoesNotThrow(
                () -> service.deleteStoredFile("document-123.pdf")
        );
    }

    @Test
    void rejectsPathOutsideStorageAndPreservesFile() throws Exception {

        Path storage = Files.createDirectory(
                temporaryDirectory.resolve("uploads")
        );

        Path outsideFile = temporaryDirectory.resolve("document-123.pdf");
        Files.writeString(outsideFile, "Keep this file.");

        FileStorageService service =
                new FileStorageService(storage.toString());

        assertThrows(
                IllegalArgumentException.class,
                () -> service.deleteStoredFile("../document-123.pdf")
        );

        assertEquals("Keep this file.", Files.readString(outsideFile));
    }

    @Test
    void rejectsNonGeneratedFilenameAndPreservesFile() throws Exception {

        Path existingFile = temporaryDirectory.resolve("report.pdf");
        Files.writeString(existingFile, "Keep this file.");

        FileStorageService service =
                new FileStorageService(temporaryDirectory.toString());

        assertThrows(
                IllegalArgumentException.class,
                () -> service.deleteStoredFile("report.pdf")
        );

        assertTrue(Files.exists(existingFile));
    }
}
