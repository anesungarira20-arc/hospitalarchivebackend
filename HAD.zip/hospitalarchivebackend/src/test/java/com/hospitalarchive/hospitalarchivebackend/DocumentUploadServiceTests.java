package com.hospitalarchive.hospitalarchivebackend;

import com.hospitalarchive.hospitalarchivebackend.dto.UploadDocumentRequest;
import com.hospitalarchive.hospitalarchivebackend.model.ArchiveDocument;
import com.hospitalarchive.hospitalarchivebackend.service.DocumentService;
import com.hospitalarchive.hospitalarchivebackend.service.DocumentUploadService;
import com.hospitalarchive.hospitalarchivebackend.service.FileStorageService;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.mock.web.MockMultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DocumentUploadServiceTests {

    private final FileStorageService fileStorageService =
            mock(FileStorageService.class);

    private final DocumentService documentService =
            mock(DocumentService.class);

    private final DocumentUploadService uploadService =
            new DocumentUploadService(fileStorageService, documentService);

    private UploadDocumentRequest createRequest() {
        UploadDocumentRequest request = new UploadDocumentRequest();
        request.setPatientID(1);
        request.setDocumentTypeID(2);
        request.setDepartmentID(3);
        request.setDocumentTitle("Upload Test");
        return request;
    }

    private MockMultipartFile createFile() {
        return new MockMultipartFile(
                "file",
                "report.pdf",
                "application/pdf",
                "%PDF-1.4\nTest\n%%EOF"
                        .getBytes(StandardCharsets.US_ASCII)
        );
    }

    @Test
    void uploadSavesGeneratedFilenameAndUploader() throws Exception {

        MockMultipartFile file = createFile();

        when(fileStorageService.storePdf(file))
                .thenReturn("document-123.pdf");

        when(documentService.saveDocument(any(ArchiveDocument.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        ArchiveDocument result =
                uploadService.uploadDocument(createRequest(), file, 7);

        ArgumentCaptor<ArchiveDocument> captor =
                ArgumentCaptor.forClass(ArchiveDocument.class);

        verify(documentService).saveDocument(captor.capture());

        ArchiveDocument saved = captor.getValue();

        assertSame(saved, result);
        assertEquals(1, saved.getPatientID());
        assertEquals(2, saved.getDocumentTypeID());
        assertEquals(3, saved.getDepartmentID());
        assertEquals(7, saved.getUploadedBy());
        assertEquals("Upload Test", saved.getDocumentTitle());
        assertEquals("document-123.pdf", saved.getFileName());
        assertEquals("document-123.pdf", saved.getFilePath());
        assertEquals("pdf", saved.getFileFormat());

        verify(fileStorageService, never()).deleteStoredFile(anyString());
    }

    @Test
    void failedDocumentSaveRemovesStoredFile() throws Exception {

        MockMultipartFile file = createFile();

        when(fileStorageService.storePdf(file))
                .thenReturn("document-123.pdf");

        IllegalArgumentException failure =
                new IllegalArgumentException("Patient does not exist.");

        when(documentService.saveDocument(any(ArchiveDocument.class)))
                .thenThrow(failure);

        IllegalArgumentException thrown = assertThrows(
                IllegalArgumentException.class,
                () -> uploadService.uploadDocument(createRequest(), file, 7)
        );

        assertSame(failure, thrown);
        verify(fileStorageService).deleteStoredFile("document-123.pdf");
    }

    @Test
    void cleanupFailurePreservesOriginalError() throws Exception {

        MockMultipartFile file = createFile();

        when(fileStorageService.storePdf(file))
                .thenReturn("document-123.pdf");

        IllegalArgumentException originalFailure =
                new IllegalArgumentException("Patient does not exist.");

        IOException cleanupFailure = new IOException("Cleanup failed.");

        when(documentService.saveDocument(any(ArchiveDocument.class)))
                .thenThrow(originalFailure);

        doThrow(cleanupFailure)
                .when(fileStorageService)
                .deleteStoredFile("document-123.pdf");

        IllegalArgumentException thrown = assertThrows(
                IllegalArgumentException.class,
                () -> uploadService.uploadDocument(createRequest(), file, 7)
        );

        assertSame(originalFailure, thrown);
        assertEquals(1, thrown.getSuppressed().length);
        assertSame(cleanupFailure, thrown.getSuppressed()[0]);
    }

    @Test
    void storageFailureDoesNotSaveDocument() throws Exception {

        MockMultipartFile file = createFile();

        when(fileStorageService.storePdf(file))
                .thenThrow(new IOException("Storage failed."));

        assertThrows(
                IOException.class,
                () -> uploadService.uploadDocument(createRequest(), file, 7)
        );

        verifyNoInteractions(documentService);
        verify(fileStorageService, never()).deleteStoredFile(anyString());
    }

    @Test
    void missingRequestDoesNotStoreFile() {

        assertThrows(
                IllegalArgumentException.class,
                () -> uploadService.uploadDocument(null, createFile(), 7)
        );

        verifyNoInteractions(fileStorageService, documentService);
    }

    @Test
    void invalidUploaderDoesNotStoreFile() {

        assertThrows(
                IllegalArgumentException.class,
                () -> uploadService.uploadDocument(
                        createRequest(),
                        createFile(),
                        0
                )
        );

        verifyNoInteractions(fileStorageService, documentService);
    }
}
