package com.hospitalarchive.hospitalarchivebackend;

import com.hospitalarchive.hospitalarchivebackend.model.Auditlog;
import com.hospitalarchive.hospitalarchivebackend.repository.InMemoryAuditLogRepository;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class InMemoryAuditLogRepositoryTests {

    private final InMemoryAuditLogRepository repository =
            new InMemoryAuditLogRepository();

    private Auditlog createLog() {
        return new Auditlog(
                0,
                1,
                10,
                "CREATE",
                "Created document details.",
                LocalDateTime.of(2026, 9, 15, 10, 0)
        );
    }

    @Test
    void saveAssignsDistinctIds() {

        Auditlog first = repository.save(createLog());
        Auditlog second = repository.save(createLog());

        assertTrue(first.getLogID() > 0);
        assertTrue(second.getLogID() > 0);
        assertNotEquals(first.getLogID(), second.getLogID());
        assertEquals(2, repository.findAll().size());
    }

    @Test
    void saveRejectsOverwrite() {

        Auditlog saved = repository.save(createLog());
        saved.setActionDescription("Changed description.");

        assertThrows(
                IllegalArgumentException.class,
                () -> repository.save(saved)
        );

        Auditlog stored = repository.findById(saved.getLogID()).orElseThrow();

        assertEquals("Created document details.", stored.getActionDescription());
        assertEquals(1, repository.findAll().size());
    }

    @Test
    void changingInputOrReturnedLogDoesNotChangeStoredLog() {

        Auditlog input = createLog();
        Auditlog saved = repository.save(input);
        int logID = saved.getLogID();

        input.setAction("ALTERED");
        saved.setActionDescription("Altered returned object.");

        Auditlog retrieved = repository.findById(logID).orElseThrow();

        assertEquals("CREATE", retrieved.getAction());
        assertEquals("Created document details.", retrieved.getActionDescription());

        retrieved.setUserID(999);

        assertEquals(
                1,
                repository.findById(logID).orElseThrow().getUserID()
        );
    }

    @Test
    void documentFilterExcludesUnrelatedAndMissingDocumentIds() {

        repository.save(createLog());

        Auditlog unrelated = createLog();
        unrelated.setDocumentID(20);
        repository.save(unrelated);

        Auditlog loginLog = createLog();
        loginLog.setDocumentID(null);
        repository.save(loginLog);

        assertEquals(1, repository.findByDocumentID(10).size());
        assertEquals(3, repository.findAll().size());
    }
}
