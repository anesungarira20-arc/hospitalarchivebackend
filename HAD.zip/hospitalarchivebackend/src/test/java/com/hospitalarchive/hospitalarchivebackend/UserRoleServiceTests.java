package com.hospitalarchive.hospitalarchivebackend;

import com.hospitalarchive.hospitalarchivebackend.model.User;
import com.hospitalarchive.hospitalarchivebackend.repository.UserRepository;
import com.hospitalarchive.hospitalarchivebackend.service.UserService;

import org.junit.jupiter.api.Test;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserRoleServiceTests {

    private final UserRepository userRepository =
            mock(UserRepository.class);

    private final PasswordEncoder passwordEncoder =
            mock(PasswordEncoder.class);

    private final UserService userService =
            new UserService(userRepository, passwordEncoder);

    @Test
    void updateRolePreservesPasswordAndUserDetails() {

        User user = new User(
                2,
                "Test Staff",
                "test_staff",
                "existing-password-hash",
                "READ_ONLY",
                "staff@example.com"
        );

        when(userRepository.findById(2))
                .thenReturn(Optional.of(user));

        when(userRepository.save(any(User.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        User updatedUser = userService.updateUserRole(2, "ARCHIVE_STAFF");

        assertEquals("ARCHIVE_STAFF", updatedUser.getRole());
        assertEquals("existing-password-hash", updatedUser.getPassword());
        assertEquals(2, updatedUser.getUserID());
        assertEquals("test_staff", updatedUser.getUsername());
        assertEquals("Test Staff", updatedUser.getFullName());
        assertEquals("staff@example.com", updatedUser.getEmail());

        verify(userRepository).save(user);
        verifyNoInteractions(passwordEncoder);
    }

    @Test
    void updateRoleRejectsUnknownRole() {

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> userService.updateUserRole(2, "SUPERUSER")
        );

        assertEquals(
                "Role must be ADMIN, ARCHIVE_STAFF, or READ_ONLY.",
                exception.getMessage()
        );

        verifyNoInteractions(userRepository, passwordEncoder);
    }

    @Test
    void updateRoleRejectsNullRole() {

        assertThrows(
                IllegalArgumentException.class,
                () -> userService.updateUserRole(2, null)
        );

        verifyNoInteractions(userRepository, passwordEncoder);
    }

    @Test
    void updateRoleRejectsMissingUser() {

        when(userRepository.findById(99))
                .thenReturn(Optional.empty());

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> userService.updateUserRole(99, "ARCHIVE_STAFF")
        );

        assertEquals("User does not exist.", exception.getMessage());
        verify(userRepository, never()).save(any(User.class));
        verifyNoInteractions(passwordEncoder);
    }
}
