package com.hospitalarchive.hospitalarchivebackend;

import com.hospitalarchive.hospitalarchivebackend.model.Department;
import com.hospitalarchive.hospitalarchivebackend.model.ArchiveDocument;
import com.hospitalarchive.hospitalarchivebackend.repository.DepartmentRepository;
import com.hospitalarchive.hospitalarchivebackend.repository.DocumentRepository;
import com.hospitalarchive.hospitalarchivebackend.service.DepartmentService;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DepartmentServiceTests {

    private final DepartmentRepository departmentRepository =
            mock(DepartmentRepository.class);

    private final DocumentRepository documentRepository =
            mock(DocumentRepository.class);

    private final DepartmentService departmentService = new DepartmentService(
            departmentRepository,
            documentRepository
    );

    @Test
    void saveDepartmentAcceptsValidDepartment() {

        Department department = new Department();
        department.setDepartmentName("Radiology");

        when(departmentRepository.save(department)).thenReturn(department);

        Department savedDepartment =
                departmentService.saveDepartment(department);

        assertSame(department, savedDepartment);
        verify(departmentRepository).save(department);
    }

    @Test
    void saveDepartmentRejectsNullDepartment() {

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> departmentService.saveDepartment(null)
        );

        assertEquals("Department cannot be null.", exception.getMessage());
        verifyNoInteractions(departmentRepository);
    }

    @Test
    void saveDepartmentRejectsBlankName() {

        Department department = new Department();
        department.setDepartmentName("   ");

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> departmentService.saveDepartment(department)
        );

        assertEquals("Department name is required.", exception.getMessage());
        verifyNoInteractions(departmentRepository);
    }

    @Test
    void saveDepartmentRejectsNullName() {

        Department department = new Department();

        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> departmentService.saveDepartment(department)
        );

        assertEquals("Department name is required.", exception.getMessage());
        verifyNoInteractions(departmentRepository);
    }

    @Test
    void deleteDepartmentRejectsDepartmentWithLinkedDocuments() {

        ArchiveDocument document = new ArchiveDocument();
        document.setDocumentID(10);
        document.setDepartmentID(1);

        when(documentRepository.findByDepartmentID(1))
                .thenReturn(List.of(document));

        IllegalStateException exception = assertThrows(
                IllegalStateException.class,
                () -> departmentService.deleteDepartment(1)
        );

        assertEquals(
                "Cannot delete a department that has linked documents.",
                exception.getMessage()
        );

        verifyNoInteractions(departmentRepository);
    }

    @Test
    void deleteDepartmentAllowsDepartmentWithoutLinkedDocuments() {

        when(documentRepository.findByDepartmentID(1))
                .thenReturn(List.of());

        departmentService.deleteDepartment(1);

        verify(departmentRepository).deleteById(1);
    }
}