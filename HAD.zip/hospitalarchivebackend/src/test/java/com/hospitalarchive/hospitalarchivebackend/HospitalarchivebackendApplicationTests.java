package com.hospitalarchive.hospitalarchivebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalarchivebackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
