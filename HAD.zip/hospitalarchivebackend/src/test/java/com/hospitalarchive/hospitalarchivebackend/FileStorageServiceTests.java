package com.hospitalarchive.hospitalarchivebackend;

import com.hospitalarchive.hospitalarchivebackend.service.FileStorageService;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.mock.web.MockMultipartFile;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class FileStorageServiceTests {

    @TempDir
    Path temporaryDirectory;

    // Sample bytes for testing the basic PDF header check
    private byte[] sampleContent() {
        return "%PDF-1.4\nTest content\n%%EOF"
                .getBytes(StandardCharsets.US_ASCII);
    }

    @Test
    void storesFileWithGeneratedNameAndPreservesContents() throws Exception {

        FileStorageService service =
                new FileStorageService(temporaryDirectory.toString());

        byte[] content = sampleContent();

        MockMultipartFile file = new MockMultipartFile(
                "file",
                "report.pdf",
                "application/pdf",
                content
        );

        String storedName = service.storePdf(file);
        Path storedPath = temporaryDirectory.resolve(storedName);

        assertNotEquals("report.pdf", storedName);
        assertTrue(storedName.endsWith(".pdf"));
        assertEquals(temporaryDirectory, storedPath.getParent());
        assertArrayEquals(content, Files.readAllBytes(storedPath));
    }

    @Test
    void sameOriginalFilenameDoesNotOverwriteExistingFile() throws Exception {

        FileStorageService service =
                new FileStorageService(temporaryDirectory.toString());

        MockMultipartFile file = new MockMultipartFile(
                "file",
                "report.pdf",
                "application/pdf",
                sampleContent()
        );

        String firstName = service.storePdf(file);
        String secondName = service.storePdf(file);

        assertNotEquals(firstName, secondName);
        assertTrue(Files.exists(temporaryDirectory.resolve(firstName)));
        assertTrue(Files.exists(temporaryDirectory.resolve(secondName)));
    }

    @Test
    void suppliedPathCannotChooseStorageLocation() throws Exception {

        FileStorageService service =
                new FileStorageService(temporaryDirectory.toString());

        MockMultipartFile file = new MockMultipartFile(
                "file",
                "../../outside.pdf",
                "application/pdf",
                sampleContent()
        );

        String storedName = service.storePdf(file);
        Path storedPath = temporaryDirectory.resolve(storedName).normalize();

        assertEquals(temporaryDirectory, storedPath.getParent());
        assertFalse(storedName.contains("/"));
        assertFalse(storedName.contains("\\"));
        assertTrue(Files.exists(storedPath));
    }

    @Test
    void rejectsEmptyFile() {

        FileStorageService service =
                new FileStorageService(temporaryDirectory.toString());

        MockMultipartFile file = new MockMultipartFile(
                "file",
                "empty.pdf",
                "application/pdf",
                new byte[0]
        );

        assertThrows(
                IllegalArgumentException.class,
                () -> service.storePdf(file)
        );
    }

    @Test
    void rejectsNonPdfExtension() {

        FileStorageService service =
                new FileStorageService(temporaryDirectory.toString());

        MockMultipartFile file = new MockMultipartFile(
                "file",
                "report.txt",
                "text/plain",
                sampleContent()
        );

        assertThrows(
                IllegalArgumentException.class,
                () -> service.storePdf(file)
        );
    }

    @Test
    void rejectsMissingPdfHeader() {

        FileStorageService service =
                new FileStorageService(temporaryDirectory.toString());

        MockMultipartFile file = new MockMultipartFile(
                "file",
                "report.pdf",
                "application/pdf",
                "Not a PDF".getBytes(StandardCharsets.UTF_8)
        );

        assertThrows(
                IllegalArgumentException.class,
                () -> service.storePdf(file)
        );
    }

    @Test
    void rejectsFileLargerThanLimit() {

        FileStorageService service =
                new FileStorageService(temporaryDirectory.toString());

        MockMultipartFile file = new MockMultipartFile(
                "file",
                "large.pdf",
                "application/pdf",
                new byte[10 * 1024 * 1024 + 1]
        );

        assertThrows(
                IllegalArgumentException.class,
                () -> service.storePdf(file)
        );
    }
}
