package com.hospitalarchive.hospitalarchivebackend.repository;

import com.hospitalarchive.hospitalarchivebackend.model.Department;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class InMemoryDepartmentRepository implements DepartmentRepository {

    private final Map<Integer, Department> departments = new LinkedHashMap<>();
    private int nextDepartmentID = 1;

    // Add or update a department
    @Override
    public synchronized Department save(Department department) {

        if (department == null) {
            throw new IllegalArgumentException("Department cannot be null.");
        }

        if (department.getDepartmentID() < 0) {
            throw new IllegalArgumentException("Department ID cannot be negative.");
        }

        // An ID of zero means this is a new department
        if (department.getDepartmentID() == 0) {
            department.setDepartmentID(nextDepartmentID++);
        } else {
            nextDepartmentID = Math.max(
                    nextDepartmentID,
                    department.getDepartmentID() + 1
            );
        }

        departments.put(
                department.getDepartmentID(),
                copyDepartment(department)
        );

        return copyDepartment(department);
    }

    // Find a department by ID
    @Override
    public synchronized Optional<Department> findById(int departmentID) {

        Department department = departments.get(departmentID);

        if (department == null) {
            return Optional.empty();
        }

        return Optional.of(copyDepartment(department));
    }

    // Find a department by name
    @Override
    public synchronized Optional<Department> findByDepartmentName(
            String departmentName) {

        if (departmentName == null) {
            return Optional.empty();
        }

        for (Department department : departments.values()) {
            if (departmentName.equals(department.getDepartmentName())) {
                return Optional.of(copyDepartment(department));
            }
        }

        return Optional.empty();
    }

    // Get all departments
    @Override
    public synchronized List<Department> findAll() {

        List<Department> results = new ArrayList<>();

        for (Department department : departments.values()) {
            results.add(copyDepartment(department));
        }

        return results;
    }

    // Check whether a department name exists
    @Override
    public synchronized boolean existsByDepartmentName(String departmentName) {
        return findByDepartmentName(departmentName).isPresent();
    }

    // Delete a department
    @Override
    public synchronized void deleteById(int departmentID) {
        departments.remove(departmentID);
    }

    // Return a copy so stored details only change through save
    private Department copyDepartment(Department department) {
        return new Department(
                department.getDepartmentID(),
                department.getDepartmentName()
        );
    }
}