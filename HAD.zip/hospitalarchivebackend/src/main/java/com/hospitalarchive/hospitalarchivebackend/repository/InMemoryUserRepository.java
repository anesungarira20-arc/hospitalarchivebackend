package com.hospitalarchive.hospitalarchivebackend.repository;

import com.hospitalarchive.hospitalarchivebackend.model.User;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class InMemoryUserRepository implements UserRepository {

    private final Map<Integer, User> users = new LinkedHashMap<>();
    private int nextUserID = 1;

    // Add or update a user
    @Override
    public synchronized User save(User user) {

        if (user == null) {
            throw new IllegalArgumentException("User cannot be null.");
        }

        if (user.getUserID() < 0) {
            throw new IllegalArgumentException("User ID cannot be negative.");
        }

        if (user.getUsername() == null || user.getUsername().isBlank()) {
            throw new IllegalArgumentException("Username is required.");
        }

        // Prevent another user from using the same username
        for (User existingUser : users.values()) {

            boolean sameUsername = user.getUsername()
                    .equals(existingUser.getUsername());

            boolean differentUser = user.getUserID()
                    != existingUser.getUserID();

            if (sameUsername && differentUser) {
                throw new IllegalArgumentException(
                        "Username already belongs to another user."
                );
            }
        }

        // An ID of zero means this is a new user
        if (user.getUserID() == 0) {
            user.setUserID(nextUserID++);
        } else {
            nextUserID = Math.max(
                    nextUserID,
                    user.getUserID() + 1
            );
        }

        users.put(user.getUserID(), copyUser(user));

        return copyUser(user);
    }

    // Find a user by ID
    @Override
    public synchronized Optional<User> findById(int userID) {

        User user = users.get(userID);

        if (user == null) {
            return Optional.empty();
        }

        return Optional.of(copyUser(user));
    }

    // Find a user by username
    @Override
    public synchronized Optional<User> findByUsername(String username) {

        if (username == null) {
            return Optional.empty();
        }

        for (User user : users.values()) {
            if (username.equals(user.getUsername())) {
                return Optional.of(copyUser(user));
            }
        }

        return Optional.empty();
    }

    // Get all users
    @Override
    public synchronized List<User> findAll() {

        List<User> results = new ArrayList<>();

        for (User user : users.values()) {
            results.add(copyUser(user));
        }

        return results;
    }

    // Check whether a username exists
    @Override
    public synchronized boolean existsByUsername(String username) {
        return findByUsername(username).isPresent();
    }

    // Delete a user
    @Override
    public synchronized void deleteById(int userID) {
        users.remove(userID);
    }

    // Return a copy so stored details only change through save
    private User copyUser(User user) {
        return new User(
                user.getUserID(),
                user.getFullName(),
                user.getUsername(),
                user.getPassword(),
                user.getRole(),
                user.getEmail()
        );
    }
}
