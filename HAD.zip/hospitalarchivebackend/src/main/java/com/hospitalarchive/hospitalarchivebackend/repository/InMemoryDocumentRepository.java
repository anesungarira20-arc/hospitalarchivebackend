package com.hospitalarchive.hospitalarchivebackend.repository;

import com.hospitalarchive.hospitalarchivebackend.model.ArchiveDocument;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class InMemoryDocumentRepository implements DocumentRepository {

    private final Map<Integer, ArchiveDocument> documents =
            new LinkedHashMap<>();

    private int nextDocumentID = 1;

    // Add or update document details
    @Override
    public synchronized ArchiveDocument save(ArchiveDocument document) {

        if (document == null) {
            throw new IllegalArgumentException("Document cannot be null.");
        }

        if (document.getDocumentID() < 0) {
            throw new IllegalArgumentException("Document ID cannot be negative.");
        }

        // An ID of zero means this is a new document
        if (document.getDocumentID() == 0) {
            document.setDocumentID(nextDocumentID++);
        } else {
            nextDocumentID = Math.max(
                    nextDocumentID,
                    document.getDocumentID() + 1
            );
        }

        documents.put(document.getDocumentID(), copyDocument(document));

        return copyDocument(document);
    }

    // Find a document by ID
    @Override
    public synchronized Optional<ArchiveDocument> findById(int documentID) {

        ArchiveDocument document = documents.get(documentID);

        if (document == null) {
            return Optional.empty();
        }

        return Optional.of(copyDocument(document));
    }

    // Get all documents
    @Override
    public synchronized List<ArchiveDocument> findAll() {

        List<ArchiveDocument> results = new ArrayList<>();

        for (ArchiveDocument document : documents.values()) {
            results.add(copyDocument(document));
        }

        return results;
    }

    // Get documents belonging to a patient
    @Override
    public synchronized List<ArchiveDocument> findByPatientID(int patientID) {

        List<ArchiveDocument> results = new ArrayList<>();

        for (ArchiveDocument document : documents.values()) {
            if (document.getPatientID() == patientID) {
                results.add(copyDocument(document));
            }
        }

        return results;
    }

    // Get documents from a department
    @Override
    public synchronized List<ArchiveDocument> findByDepartmentID(
            int departmentID) {

        List<ArchiveDocument> results = new ArrayList<>();

        for (ArchiveDocument document : documents.values()) {
            if (document.getDepartmentID() == departmentID) {
                results.add(copyDocument(document));
            }
        }

        return results;
    }

    // Get documents of a particular type
    @Override
    public synchronized List<ArchiveDocument> findByDocumentTypeID(
            int documentTypeID) {

        List<ArchiveDocument> results = new ArrayList<>();

        for (ArchiveDocument document : documents.values()) {
            if (document.getDocumentTypeID() == documentTypeID) {
                results.add(copyDocument(document));
            }
        }

        return results;
    }

    // Search documents by title
    @Override
    public synchronized List<ArchiveDocument> findByDocumentTitleContaining(
            String title) {

        List<ArchiveDocument> results = new ArrayList<>();

        if (title == null || title.isBlank()) {
            return results;
        }

        for (ArchiveDocument document : documents.values()) {
            if (document.getDocumentTitle() != null
                    && document.getDocumentTitle().contains(title)) {
                results.add(copyDocument(document));
            }
        }

        return results;
    }

    // Delete document details
    @Override
    public synchronized void deleteById(int documentID) {
        documents.remove(documentID);
    }

    // Return a copy so stored details only change through save
    private ArchiveDocument copyDocument(ArchiveDocument document) {

        ArchiveDocument copy = new ArchiveDocument();

        copy.setDocumentID(document.getDocumentID());
        copy.setPatientID(document.getPatientID());
        copy.setDocumentTypeID(document.getDocumentTypeID());
        copy.setDepartmentID(document.getDepartmentID());
        copy.setUploadedBy(document.getUploadedBy());
        copy.setDocumentTitle(document.getDocumentTitle());
        copy.setFileName(document.getFileName());
        copy.setFilePath(document.getFilePath());
        copy.setFileFormat(document.getFileFormat());
        copy.setUploadDate(document.getUploadDate());

        return copy;
    }
}
