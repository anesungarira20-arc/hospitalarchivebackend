package com.hospitalarchive.hospitalarchivebackend.controller;

import com.hospitalarchive.hospitalarchivebackend.model.Auditlog;
import com.hospitalarchive.hospitalarchivebackend.service.AuditLogService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/audit-logs")
public class AuditLogController {

    private final AuditLogService auditLogService;

    public AuditLogController(AuditLogService auditLogService) {
        this.auditLogService = auditLogService;
    }

    // Get all audit logs
    @GetMapping
    public List<Auditlog> getAllAuditLogs() {
        return auditLogService.getAllAuditLogs();
    }

    // Find an audit log by ID
    @GetMapping("/{logID}")
    public ResponseEntity<Auditlog> getAuditLogById(
            @PathVariable("logID") int logID) {

        return auditLogService.getAuditLogById(logID)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Get audit logs for a user
    @GetMapping("/by-user/{userID}")
    public List<Auditlog> getAuditLogsByUserId(
            @PathVariable("userID") int userID) {

        return auditLogService.getAuditLogsByUserId(userID);
    }

    // Get audit logs for a document, including a deleted document
    @GetMapping("/by-document/{documentID}")
    public List<Auditlog> getAuditLogsByDocumentId(
            @PathVariable("documentID") int documentID) {

        return auditLogService.getAuditLogsByDocumentId(documentID);
    }
}
