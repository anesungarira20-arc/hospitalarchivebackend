package com.hospitalarchive.hospitalarchivebackend.repository;

import com.hospitalarchive.hospitalarchivebackend.model.DocumentType;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class InMemoryDocumentTypeRepository implements DocumentTypeRepository {

    private final Map<Integer, DocumentType> documentTypes = new LinkedHashMap<>();
    private int nextDocumentTypeID = 1;

    // Add or update a document type
    @Override
    public synchronized DocumentType save(DocumentType documentType) {

        if (documentType == null) {
            throw new IllegalArgumentException("Document type cannot be null.");
        }

        if (documentType.getDocumentTypeID() < 0) {
            throw new IllegalArgumentException("Document type ID cannot be negative.");
        }

        // An ID of zero means this is a new document type
        if (documentType.getDocumentTypeID() == 0) {
            documentType.setDocumentTypeID(nextDocumentTypeID++);
        } else {
            nextDocumentTypeID = Math.max(
                    nextDocumentTypeID,
                    documentType.getDocumentTypeID() + 1
            );
        }

        documentTypes.put(
                documentType.getDocumentTypeID(),
                copyDocumentType(documentType)
        );

        return copyDocumentType(documentType);
    }

    // Find a document type by ID
    @Override
    public synchronized Optional<DocumentType> findById(int documentTypeID) {

        DocumentType documentType = documentTypes.get(documentTypeID);

        if (documentType == null) {
            return Optional.empty();
        }

        return Optional.of(copyDocumentType(documentType));
    }

    // Find a document type by name
    @Override
    public synchronized Optional<DocumentType> findByDocumentTypeName(
            String documentTypeName) {

        if (documentTypeName == null) {
            return Optional.empty();
        }

        for (DocumentType documentType : documentTypes.values()) {
            if (documentTypeName.equals(documentType.getDocumentTypeName())) {
                return Optional.of(copyDocumentType(documentType));
            }
        }

        return Optional.empty();
    }

    // Get all document types
    @Override
    public synchronized List<DocumentType> findAll() {

        List<DocumentType> results = new ArrayList<>();

        for (DocumentType documentType : documentTypes.values()) {
            results.add(copyDocumentType(documentType));
        }

        return results;
    }

    // Check whether a document type name exists
    @Override
    public synchronized boolean existsByDocumentTypeName(String documentTypeName) {
        return findByDocumentTypeName(documentTypeName).isPresent();
    }

    // Delete a document type
    @Override
    public synchronized void deleteById(int documentTypeID) {
        documentTypes.remove(documentTypeID);
    }

    // Return a copy so stored details only change through save
    private DocumentType copyDocumentType(DocumentType documentType) {
        return new DocumentType(
                documentType.getDocumentTypeID(),
                documentType.getDocumentTypeName()
        );
    }
}