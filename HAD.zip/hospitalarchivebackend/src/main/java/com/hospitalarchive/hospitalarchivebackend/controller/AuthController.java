package com.hospitalarchive.hospitalarchivebackend.controller;

import com.hospitalarchive.hospitalarchivebackend.dto.LoginRequest;
import com.hospitalarchive.hospitalarchivebackend.dto.UserResponse;
import com.hospitalarchive.hospitalarchivebackend.model.User;
import com.hospitalarchive.hospitalarchivebackend.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.nio.charset.StandardCharsets;
import java.util.Map;

import static org.springframework.http.HttpStatus.UNAUTHORIZED;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final SecurityContextRepository securityContextRepository;
    private final SessionAuthenticationStrategy sessionAuthenticationStrategy;
    private final UserService userService;

    // Constructor
    public AuthController(
            AuthenticationManager authenticationManager,
            SecurityContextRepository securityContextRepository,
            SessionAuthenticationStrategy sessionAuthenticationStrategy,
            UserService userService) {

        this.authenticationManager = authenticationManager;
        this.securityContextRepository = securityContextRepository;
        this.sessionAuthenticationStrategy = sessionAuthenticationStrategy;
        this.userService = userService;
    }

    // Supply a CSRF token for requests that change data
    @GetMapping("/csrf")
    public Map<String, String> getCsrfToken(CsrfToken csrfToken) {
        return Map.of(
                "token", csrfToken.getToken(),
                "headerName", csrfToken.getHeaderName()
        );
    }

    // Authenticate a user and save the login in their session
    @PostMapping("/login")
    public UserResponse login(
            @RequestBody LoginRequest loginRequest,
            HttpServletRequest request,
            HttpServletResponse response) {

        if (loginRequest.getUsername() == null
                || loginRequest.getUsername().isBlank()
                || loginRequest.getPassword() == null
                || loginRequest.getPassword().isBlank()) {

            throw new ResponseStatusException(
                    UNAUTHORIZED,
                    "Invalid username or password."
            );
        }

        if (loginRequest.getPassword()
                .getBytes(StandardCharsets.UTF_8).length > 72) {

            throw new ResponseStatusException(
                    UNAUTHORIZED,
                    "Invalid username or password."
            );
        }

        try {
            Authentication authentication =
                    authenticationManager.authenticate(
                            UsernamePasswordAuthenticationToken.unauthenticated(
                                    loginRequest.getUsername(),
                                    loginRequest.getPassword()
                            )
                    );

            User user = userService.getUserByUsername(authentication.getName())
                    .orElseThrow(() -> new BadCredentialsException(
                            "Invalid username or password."
                    ));

            // Protect the session after successful authentication
            sessionAuthenticationStrategy.onAuthentication(
                    authentication,
                    request,
                    response
            );

            SecurityContext context =
                    SecurityContextHolder.createEmptyContext();

            context.setAuthentication(authentication);
            SecurityContextHolder.setContext(context);

            // Remember this login for subsequent requests
            securityContextRepository.saveContext(
                    context,
                    request,
                    response
            );

            return new UserResponse(user);

        } catch (AuthenticationException exception) {
            SecurityContextHolder.clearContext();

            throw new ResponseStatusException(
                    UNAUTHORIZED,
                    "Invalid username or password."
            );
        }
    }
}