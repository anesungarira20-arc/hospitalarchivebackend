package com.hospitalarchive.hospitalarchivebackend.repository;

import com.hospitalarchive.hospitalarchivebackend.model.Patient;

import java.util.List;
import java.util.Optional;

public interface PatientRepository {


    Patient save(Patient patient);

    Optional<Patient> findById(int patientID);

    Optional<Patient> findByHospitalnumber(String hospitalNumber);

    List<Patient> findAll();

    boolean existsByHospitalNumber(String hospitalNumber);


    void deleteById(int patientID);
}
