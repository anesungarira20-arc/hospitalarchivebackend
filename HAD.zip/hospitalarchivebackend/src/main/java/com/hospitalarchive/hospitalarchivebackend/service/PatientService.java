package com.hospitalarchive.hospitalarchivebackend.service;

import com.hospitalarchive.hospitalarchivebackend.model.Patient;
import com.hospitalarchive.hospitalarchivebackend.repository.PatientRepository;
import com.hospitalarchive.hospitalarchivebackend.repository.DocumentRepository;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PatientService {

    private final PatientRepository patientRepository;
    private final DocumentRepository documentRepository;

    // Constructor
    public PatientService(
            PatientRepository patientRepository,
            DocumentRepository documentRepository) {

        this.patientRepository = patientRepository;
        this.documentRepository = documentRepository;
    }

    // Add or update a patient
    public Patient savePatient(Patient patient) {

        if (patient == null) {
            throw new IllegalArgumentException("Patient cannot be null.");
        }

        if (patient.getHospitalNumber() == null
                || patient.getHospitalNumber().isBlank()) {
            throw new IllegalArgumentException("Hospital number is required.");
        }

        if (patient.getFirstName() == null
                || patient.getFirstName().isBlank()) {
            throw new IllegalArgumentException("First name is required.");
        }

        if (patient.getLastName() == null
                || patient.getLastName().isBlank()) {
            throw new IllegalArgumentException("Last name is required.");
        }

        return patientRepository.save(patient);
    }

    // Find a patient by ID
    public Optional<Patient> getPatientById(int patientID) {
        return patientRepository.findById(patientID);
    }

    // Find a patient by hospital number
    public Optional<Patient> getPatientByHospitalNumber(String hospitalNumber) {

        if (hospitalNumber == null || hospitalNumber.isBlank()) {
            return Optional.empty();
        }

        return patientRepository.findByHospitalnumber(hospitalNumber);
    }

    // Get all patients
    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    // Check whether a hospital number exists
    public boolean existsByHospitalNumber(String hospitalNumber) {

        if (hospitalNumber == null || hospitalNumber.isBlank()) {
            return false;
        }

        return patientRepository.existsByHospitalNumber(hospitalNumber);
    }

    // Delete a patient only when no documents reference them
    public void deletePatient(int patientID) {

        if (!documentRepository.findByPatientID(patientID).isEmpty()) {
            throw new IllegalStateException(
                    "Cannot delete a patient who has linked documents."
            );
        }

        patientRepository.deleteById(patientID);
    }
}