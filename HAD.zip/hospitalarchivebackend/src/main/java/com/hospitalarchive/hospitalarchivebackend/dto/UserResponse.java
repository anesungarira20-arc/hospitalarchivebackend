package com.hospitalarchive.hospitalarchivebackend.dto;

import com.hospitalarchive.hospitalarchivebackend.model.User;

public class UserResponse {

    private final int userID;
    private final String fullName;
    private final String username;
    private final String role;
    private final String email;

    public UserResponse(User user) {
        this.userID = user.getUserID();
        this.fullName = user.getFullName();
        this.username = user.getUsername();
        this.role = user.getRole();
        this.email = user.getEmail();
    }

    public int getUserID() {
        return userID;
    }

    public String getFullName() {
        return fullName;
    }

    public String getUsername() {
        return username;
    }

    public String getRole() {
        return role;
    }

    public String getEmail() {
        return email;
    }
}
