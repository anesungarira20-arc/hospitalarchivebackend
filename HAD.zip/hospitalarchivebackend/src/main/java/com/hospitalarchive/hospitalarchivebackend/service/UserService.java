package com.hospitalarchive.hospitalarchivebackend.service;

import com.hospitalarchive.hospitalarchivebackend.model.User;
import com.hospitalarchive.hospitalarchivebackend.repository.UserRepository;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    // Constructor
    public UserService(
            UserRepository userRepository,
            PasswordEncoder passwordEncoder) {

        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // Create a new user with a hashed password
    public User saveUser(User user) {

        if (user == null) {
            throw new IllegalArgumentException("User cannot be null.");
        }

        if (user.getUserID() != 0) {
            throw new IllegalArgumentException(
                    "User ID must be zero when creating a user."
            );
        }

        if (user.getUsername() == null || user.getUsername().isBlank()) {
            throw new IllegalArgumentException("Username is required.");
        }

        if (user.getPassword() == null || user.getPassword().isBlank()) {
            throw new IllegalArgumentException("Password is required.");
        }

        // BCrypt supports passwords up to 72 bytes
        if (user.getPassword().getBytes(StandardCharsets.UTF_8).length > 72) {
            throw new IllegalArgumentException(
                    "Password must not exceed 72 UTF-8 bytes."
            );
        }

        if (userRepository.existsByUsername(user.getUsername())) {
            throw new IllegalArgumentException(
                    "Username already belongs to another user."
            );
        }

        // Hash a copy so the supplied user's password is not changed
        User userToSave = new User(
                0,
                user.getFullName(),
                user.getUsername(),
                passwordEncoder.encode(user.getPassword()),
                user.getRole(),
                user.getEmail()
        );

        return userRepository.save(userToSave);
    }

    // Find a user by ID
    public Optional<User> getUserById(int userID) {
        return userRepository.findById(userID);
    }

    // Find a user by username
    public Optional<User> getUserByUsername(String username) {

        if (username == null || username.isBlank()) {
            return Optional.empty();
        }

        return userRepository.findByUsername(username);
    }

    // Get all users
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // Change an existing user's role
    public User updateUserRole(int userID, String role) {

        if (role == null
                || (!role.equals("ADMIN")
                && !role.equals("ARCHIVE_STAFF")
                && !role.equals("READ_ONLY"))) {

            throw new IllegalArgumentException(
                    "Role must be ADMIN, ARCHIVE_STAFF, or READ_ONLY."
            );
        }

        User user = userRepository.findById(userID)
                .orElseThrow(() -> new IllegalArgumentException(
                        "User does not exist."
                ));

        user.setRole(role);

        // Save directly to preserve the existing password hash
        return userRepository.save(user);
    }

    // Delete a user
    public void deleteUser(int userID) {
        userRepository.deleteById(userID);
    }
}
