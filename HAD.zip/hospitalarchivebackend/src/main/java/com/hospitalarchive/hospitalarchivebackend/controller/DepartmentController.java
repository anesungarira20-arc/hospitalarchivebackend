package com.hospitalarchive.hospitalarchivebackend.controller;

import com.hospitalarchive.hospitalarchivebackend.model.Department;
import com.hospitalarchive.hospitalarchivebackend.service.DepartmentService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.net.URI;
import java.util.List;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

@RestController
@RequestMapping("/api/departments")
public class DepartmentController {

    private final DepartmentService departmentService;

    // Constructor
    public DepartmentController(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    // Get all departments
    @GetMapping
    public List<Department> getAllDepartments() {
        return departmentService.getAllDepartments();
    }

    // Find a department by ID
    @GetMapping("/{departmentID}")
    public ResponseEntity<Department> getDepartmentById(
            @PathVariable("departmentID") int departmentID) {

        return departmentService.getDepartmentById(departmentID)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Create a department
    @PostMapping
    public ResponseEntity<Department> createDepartment(
            @RequestBody Department department) {

        if (department.getDepartmentID() != 0) {
            throw new ResponseStatusException(
                    BAD_REQUEST,
                    "Leave department ID as zero when creating a department."
            );
        }

        Department savedDepartment = saveValidatedDepartment(department);

        URI location = URI.create(
                "/api/departments/" + savedDepartment.getDepartmentID()
        );

        return ResponseEntity.created(location).body(savedDepartment);
    }

    // Update an existing department
    @PutMapping("/{departmentID}")
    public ResponseEntity<Department> updateDepartment(
            @PathVariable("departmentID") int departmentID,
            @RequestBody Department department) {

        if (department.getDepartmentID() != 0
                && department.getDepartmentID() != departmentID) {
            throw new ResponseStatusException(
                    BAD_REQUEST,
                    "Department ID in the body must match the URL or be zero."
            );
        }

        if (departmentService.getDepartmentById(departmentID).isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        department.setDepartmentID(departmentID);

        Department savedDepartment = saveValidatedDepartment(department);

        return ResponseEntity.ok(savedDepartment);
    }

    // Delete an existing department
    @DeleteMapping("/{departmentID}")
    public ResponseEntity<Void> deleteDepartment(
            @PathVariable("departmentID") int departmentID) {

        if (departmentService.getDepartmentById(departmentID).isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        try {
            departmentService.deleteDepartment(departmentID);
        } catch (IllegalStateException exception) {
            throw new ResponseStatusException(
                    org.springframework.http.HttpStatus.CONFLICT,
                    exception.getMessage()
            );
        }

        return ResponseEntity.noContent().build();
    }

    // Convert validation failures into a Bad Request response
    private Department saveValidatedDepartment(Department department) {

        try {
            return departmentService.saveDepartment(department);
        } catch (IllegalArgumentException exception) {
            throw new ResponseStatusException(
                    BAD_REQUEST,
                    exception.getMessage()
            );
        }
    }
}
