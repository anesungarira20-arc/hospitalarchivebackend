package com.hospitalarchive.hospitalarchivebackend.controller;

import com.hospitalarchive.hospitalarchivebackend.dto.UploadDocumentRequest;
import com.hospitalarchive.hospitalarchivebackend.model.ArchiveDocument;
import com.hospitalarchive.hospitalarchivebackend.model.Auditlog;
import com.hospitalarchive.hospitalarchivebackend.model.User;
import com.hospitalarchive.hospitalarchivebackend.service.AuditLogService;
import com.hospitalarchive.hospitalarchivebackend.service.DocumentUploadService;
import com.hospitalarchive.hospitalarchivebackend.service.UserService;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.net.URI;
import java.security.Principal;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.HttpStatus.UNAUTHORIZED;

@RestController
@RequestMapping("/api/documents")
public class DocumentUploadController {

    private final DocumentUploadService documentUploadService;
    private final UserService userService;
    private final AuditLogService auditLogService;

    public DocumentUploadController(
            DocumentUploadService documentUploadService,
            UserService userService,
            AuditLogService auditLogService) {

        this.documentUploadService = documentUploadService;
        this.userService = userService;
        this.auditLogService = auditLogService;
    }

    // Receive a PDF and its accompanying form fields
    @PostMapping(
            value = "/upload",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE
    )
    public ResponseEntity<ArchiveDocument> uploadDocument(
            @ModelAttribute UploadDocumentRequest details,
            @RequestParam("file") MultipartFile file,
            Principal principal) {

        if (principal == null) {
            throw new ResponseStatusException(
                    UNAUTHORIZED,
                    "Login is required."
            );
        }

        User uploader = userService.getUserByUsername(principal.getName())
                .orElseThrow(() -> new ResponseStatusException(
                        UNAUTHORIZED,
                        "Please log in again."
                ));

        ArchiveDocument savedDocument;

        try {
            savedDocument = documentUploadService.uploadDocument(
                    details,
                    file,
                    uploader.getUserID()
            );
        } catch (IllegalArgumentException exception) {
            throw new ResponseStatusException(
                    BAD_REQUEST,
                    exception.getMessage()
            );
        } catch (IOException exception) {
            throw new ResponseStatusException(
                    INTERNAL_SERVER_ERROR,
                    "The uploaded file could not be stored.",
                    exception
            );
        }

        // Record the successful upload
        Auditlog auditLog = new Auditlog();
        auditLog.setUserID(uploader.getUserID());
        auditLog.setDocumentID(savedDocument.getDocumentID());
        auditLog.setAction("UPLOAD");
        auditLog.setActionDescription("Uploaded a PDF document.");

        auditLogService.saveAuditLog(auditLog);

        URI location = URI.create(
                "/api/documents/" + savedDocument.getDocumentID()
        );

        return ResponseEntity.created(location).body(savedDocument);
    }
}
