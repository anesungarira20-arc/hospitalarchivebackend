package com.hospitalarchive.hospitalarchivebackend.repository;

import com.hospitalarchive.hospitalarchivebackend.model.User;

import java.util.List;
import java.util.Optional;

public interface UserRepository {

    // Add or update a user
    User save(User user);

    // Find a user by ID
    Optional<User> findById(int userID);

    // Find a user by username
    Optional<User> findByUsername(String username);

    // Get all users
    List<User> findAll();

    // Check whether a username exists
    boolean existsByUsername(String username);

    // Delete a user
    void deleteById(int userID);
}
