package com.hospitalarchive.hospitalarchivebackend.repository;

import com.hospitalarchive.hospitalarchivebackend.model.Patient;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class InMemoryPatientRepository implements PatientRepository {

    private final Map<Integer, Patient> patients = new LinkedHashMap<>();
    private int nextPatientID = 1;

    // Add or update a patient
    @Override
    public synchronized Patient save(Patient patient) {

        if (patient == null) {
            throw new IllegalArgumentException("Patient cannot be null.");
        }

        if (patient.getPatientID() < 0) {
            throw new IllegalArgumentException("Patient ID cannot be negative.");
        }

        if (patient.getHospitalNumber() == null
                || patient.getHospitalNumber().isBlank()) {
            throw new IllegalArgumentException("Hospital number is required.");
        }

        // Prevent another patient from using the same hospital number
        for (Patient existingPatient : patients.values()) {

            boolean sameHospitalNumber = patient.getHospitalNumber()
                    .equals(existingPatient.getHospitalNumber());

            boolean differentPatient = patient.getPatientID()
                    != existingPatient.getPatientID();

            if (sameHospitalNumber && differentPatient) {
                throw new IllegalArgumentException(
                        "Hospital number already belongs to another patient."
                );
            }
        }

        // An ID of zero means this is a new patient
        if (patient.getPatientID() == 0) {
            patient.setPatientID(nextPatientID++);
        } else {
            nextPatientID = Math.max(
                    nextPatientID,
                    patient.getPatientID() + 1
            );
        }

        patients.put(patient.getPatientID(), copyPatient(patient));

        return copyPatient(patient);
    }

    // Find a patient by ID
    @Override
    public synchronized Optional<Patient> findById(int patientID) {

        Patient patient = patients.get(patientID);

        if (patient == null) {
            return Optional.empty();
        }

        return Optional.of(copyPatient(patient));
    }

    // Find a patient by hospital number
    @Override
    public synchronized Optional<Patient> findByHospitalnumber(
            String hospitalNumber) {

        if (hospitalNumber == null) {
            return Optional.empty();
        }

        for (Patient patient : patients.values()) {
            if (hospitalNumber.equals(patient.getHospitalNumber())) {
                return Optional.of(copyPatient(patient));
            }
        }

        return Optional.empty();
    }

    // Get all patients
    @Override
    public synchronized List<Patient> findAll() {

        List<Patient> results = new ArrayList<>();

        for (Patient patient : patients.values()) {
            results.add(copyPatient(patient));
        }

        return results;
    }

    // Check whether a hospital number exists
    @Override
    public synchronized boolean existsByHospitalNumber(String hospitalNumber) {
        return findByHospitalnumber(hospitalNumber).isPresent();
    }

    // Delete a patient
    @Override
    public synchronized void deleteById(int patientID) {
        patients.remove(patientID);
    }

    // Return a copy so stored details only change through save
    private Patient copyPatient(Patient patient) {
        return new Patient(
                patient.getPatientID(),
                patient.getHospitalNumber(),
                patient.getFirstName(),
                patient.getLastName(),
                patient.getDateOfBirth(),
                patient.getGender(),
                patient.getPhone(),
                patient.getEmail(),
                patient.getAddress()
        );
    }
}