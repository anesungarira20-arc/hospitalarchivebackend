package com.hospitalarchive.hospitalarchivebackend.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

@Service
public class FileStorageService {

    private static final int MAX_FILE_SIZE = 10 * 1024 * 1024;

    private final Path storageDirectory;

    // Read the storage location from application.properties
    public FileStorageService(
            @Value("${hospitalarchive.storage.location}") String location) {

        this.storageDirectory = Path.of(location)
                .toAbsolutePath()
                .normalize();
    }

    // Store a PDF and return its generated storage filename
    public String storePdf(MultipartFile file) throws IOException {

        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("A file is required.");
        }

        if (file.getSize() > MAX_FILE_SIZE) {
            throw new IllegalArgumentException("File must not exceed 10 MB.");
        }

        String originalFilename = file.getOriginalFilename();

        if (originalFilename == null
                || !originalFilename.toLowerCase(Locale.ROOT).endsWith(".pdf")) {
            throw new IllegalArgumentException("Only PDF files are supported.");
        }

        byte[] content;

        // Bound the amount read, even if the reported size is incorrect
        try (InputStream input = file.getInputStream()) {
            content = input.readNBytes(MAX_FILE_SIZE + 1);
        }

        if (content.length > MAX_FILE_SIZE) {
            throw new IllegalArgumentException("File must not exceed 10 MB.");
        }

        // Check the PDF header
        if (content.length < 5
                || content[0] != '%'
                || content[1] != 'P'
                || content[2] != 'D'
                || content[3] != 'F'
                || content[4] != '-') {
            throw new IllegalArgumentException(
                    "File does not have a PDF header."
            );
        }

        Files.createDirectories(storageDirectory);

        // Generate a unique name inside the configured storage folder
        Path destination = Files.createTempFile(
                storageDirectory,
                "document-",
                ".pdf"
        );

        try {
            Files.write(destination, content);
        } catch (IOException exception) {
            try {
                Files.deleteIfExists(destination);
            } catch (IOException cleanupException) {
                exception.addSuppressed(cleanupException);
            }

            throw exception;
        }

        return destination.getFileName().toString();
    }
    // Remove a generated file when an upload cannot be completed
    public void deleteStoredFile(String storedFilename) throws IOException {

        if (storedFilename == null
                || !storedFilename.matches("document-[0-9]+\\.pdf")) {
            throw new IllegalArgumentException("Invalid stored filename.");
        }

        Path destination = storageDirectory.resolve(storedFilename).normalize();

        if (!storageDirectory.equals(destination.getParent())) {
            throw new IllegalArgumentException(
                    "File must be inside the storage directory."
            );
        }

        Files.deleteIfExists(destination);
    }
}
