package com.hospitalarchive.hospitalarchivebackend.service;

import com.hospitalarchive.hospitalarchivebackend.model.DocumentType;
import com.hospitalarchive.hospitalarchivebackend.repository.DocumentTypeRepository;
import com.hospitalarchive.hospitalarchivebackend.repository.DocumentRepository;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DocumentTypeService {

    private final DocumentTypeRepository documentTypeRepository;
    private final DocumentRepository documentRepository;

    // Constructor
    public DocumentTypeService(
            DocumentTypeRepository documentTypeRepository,
            DocumentRepository documentRepository) {

        this.documentTypeRepository = documentTypeRepository;
        this.documentRepository = documentRepository;
    }

    // Add or update a document type
    public DocumentType saveDocumentType(DocumentType documentType) {

        if (documentType == null) {
            throw new IllegalArgumentException("Document type cannot be null.");
        }

        if (documentType.getDocumentTypeName() == null
                || documentType.getDocumentTypeName().isBlank()) {
            throw new IllegalArgumentException("Document type name is required.");
        }

        return documentTypeRepository.save(documentType);
    }

    // Find a document type by ID
    public Optional<DocumentType> getDocumentTypeById(int documentTypeID) {
        return documentTypeRepository.findById(documentTypeID);
    }

    // Find a document type by name
    public Optional<DocumentType> getDocumentTypeByName(String documentTypeName) {

        if (documentTypeName == null || documentTypeName.isBlank()) {
            return Optional.empty();
        }

        return documentTypeRepository.findByDocumentTypeName(documentTypeName);
    }

    // Get all document types
    public List<DocumentType> getAllDocumentTypes() {
        return documentTypeRepository.findAll();
    }

    // Check whether a document type name exists
    public boolean existsByDocumentTypeName(String documentTypeName) {

        if (documentTypeName == null || documentTypeName.isBlank()) {
            return false;
        }

        return documentTypeRepository.existsByDocumentTypeName(documentTypeName);
    }

    // Delete a document type only when no documents reference it
    public void deleteDocumentType(int documentTypeID) {

        if (!documentRepository.findByDocumentTypeID(documentTypeID).isEmpty()) {
            throw new IllegalStateException(
                    "Cannot delete a document type that has linked documents."
            );
        }

        documentTypeRepository.deleteById(documentTypeID);
    }
}