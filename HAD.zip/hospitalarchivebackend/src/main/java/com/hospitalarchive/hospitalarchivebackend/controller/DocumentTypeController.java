package com.hospitalarchive.hospitalarchivebackend.controller;

import com.hospitalarchive.hospitalarchivebackend.model.DocumentType;
import com.hospitalarchive.hospitalarchivebackend.service.DocumentTypeService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.net.URI;
import java.util.List;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

@RestController
@RequestMapping("/api/document-types")
public class DocumentTypeController {

    private final DocumentTypeService documentTypeService;

    // Constructor
    public DocumentTypeController(DocumentTypeService documentTypeService) {
        this.documentTypeService = documentTypeService;
    }

    // Get all document types
    @GetMapping
    public List<DocumentType> getAllDocumentTypes() {
        return documentTypeService.getAllDocumentTypes();
    }

    // Find a document type by ID
    @GetMapping("/{documentTypeID}")
    public ResponseEntity<DocumentType> getDocumentTypeById(
            @PathVariable("documentTypeID") int documentTypeID) {

        return documentTypeService.getDocumentTypeById(documentTypeID)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Create a document type
    @PostMapping
    public ResponseEntity<DocumentType> createDocumentType(
            @RequestBody DocumentType documentType) {

        if (documentType.getDocumentTypeID() != 0) {
            throw new ResponseStatusException(
                    BAD_REQUEST,
                    "Leave document type ID as zero when creating a document type."
            );
        }

        DocumentType savedDocumentType =
                saveValidatedDocumentType(documentType);

        URI location = URI.create(
                "/api/document-types/" + savedDocumentType.getDocumentTypeID()
        );

        return ResponseEntity.created(location).body(savedDocumentType);
    }

    // Update an existing document type
    @PutMapping("/{documentTypeID}")
    public ResponseEntity<DocumentType> updateDocumentType(
            @PathVariable("documentTypeID") int documentTypeID,
            @RequestBody DocumentType documentType) {

        if (documentType.getDocumentTypeID() != 0
                && documentType.getDocumentTypeID() != documentTypeID) {
            throw new ResponseStatusException(
                    BAD_REQUEST,
                    "Document type ID in the body must match the URL or be zero."
            );
        }

        if (documentTypeService.getDocumentTypeById(documentTypeID).isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        documentType.setDocumentTypeID(documentTypeID);

        DocumentType savedDocumentType =
                saveValidatedDocumentType(documentType);

        return ResponseEntity.ok(savedDocumentType);
    }

    // Delete an existing document type
    @DeleteMapping("/{documentTypeID}")
    public ResponseEntity<Void> deleteDocumentType(
            @PathVariable("documentTypeID") int documentTypeID) {

        if (documentTypeService.getDocumentTypeById(documentTypeID).isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        try {
            documentTypeService.deleteDocumentType(documentTypeID);
        } catch (IllegalStateException exception) {
            throw new ResponseStatusException(
                    org.springframework.http.HttpStatus.CONFLICT,
                    exception.getMessage()
            );
        }

        return ResponseEntity.noContent().build();
    }

    // Convert validation failures into a Bad Request response
    private DocumentType saveValidatedDocumentType(DocumentType documentType) {

        try {
            return documentTypeService.saveDocumentType(documentType);
        } catch (IllegalArgumentException exception) {
            throw new ResponseStatusException(
                    BAD_REQUEST,
                    exception.getMessage()
            );
        }
    }
}
