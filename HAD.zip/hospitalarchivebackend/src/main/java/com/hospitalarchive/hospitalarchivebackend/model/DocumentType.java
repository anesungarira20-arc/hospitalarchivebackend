package com.hospitalarchive.hospitalarchivebackend.model;

public class DocumentType {

    private int  documentTypeID;
    private String documentTypeName;


public DocumentType() {
}

public DocumentType(int documentTypeID, String documentTypeName) {
    this.documentTypeID = documentTypeID;
    this.documentTypeName = documentTypeName;

}

    public int getDocumentTypeID() {
        return documentTypeID;
    }

    public void setDocumentTypeID(int documentTypeID) {
        this.documentTypeID = documentTypeID;
    }

    public String getDocumentTypeName() {
        return documentTypeName;
    }

    public void setDocumentTypeName(String documentTypeName) {
        this.documentTypeName = documentTypeName;
    }

    @Override
    public String toString() {
    return documentTypeName;
    }

}