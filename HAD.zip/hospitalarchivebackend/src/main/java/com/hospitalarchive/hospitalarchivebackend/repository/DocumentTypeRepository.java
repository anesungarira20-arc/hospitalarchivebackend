package com.hospitalarchive.hospitalarchivebackend.repository;

import com.hospitalarchive.hospitalarchivebackend.model.DocumentType;

import java.util.List;
import java.util.Optional;

public interface DocumentTypeRepository {

    DocumentType save(DocumentType documentType);

    Optional<DocumentType> findById(int documentTypeID);

    Optional<DocumentType> findByDocumentTypeName(String documentTypeName);

    List<DocumentType> findAll();

    boolean existsByDocumentTypeName(String documentTypeName);

    void deleteById(int documentTypeID);
}
