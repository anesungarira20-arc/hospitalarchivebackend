package com.hospitalarchive.hospitalarchivebackend.controller;

import com.hospitalarchive.hospitalarchivebackend.model.ArchiveDocument;
import com.hospitalarchive.hospitalarchivebackend.model.Auditlog;
import com.hospitalarchive.hospitalarchivebackend.model.User;
import com.hospitalarchive.hospitalarchivebackend.service.AuditLogService;
import com.hospitalarchive.hospitalarchivebackend.service.DocumentService;
import com.hospitalarchive.hospitalarchivebackend.service.UserService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.net.URI;
import java.security.Principal;
import java.util.List;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.UNAUTHORIZED;

@RestController
@RequestMapping("/api/documents")
public class DocumentController {

    private final DocumentService documentService;
    private final UserService userService;
    private final AuditLogService auditLogService;

    // Constructor
    public DocumentController(
            DocumentService documentService,
            UserService userService,
            AuditLogService auditLogService) {

        this.documentService = documentService;
        this.userService = userService;
        this.auditLogService = auditLogService;
    }

    // Get all documents
    @GetMapping
    public List<ArchiveDocument> getAllDocuments() {
        return documentService.getAllDocuments();
    }

    // Find a document by ID
    @GetMapping("/{documentID}")
    public ResponseEntity<ArchiveDocument> getDocumentById(
            @PathVariable("documentID") int documentID) {

        return documentService.getDocumentById(documentID)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Get documents belonging to a patient
    @GetMapping("/by-patient/{patientID}")
    public List<ArchiveDocument> getDocumentsByPatientId(
            @PathVariable("patientID") int patientID) {

        return documentService.getDocumentsByPatientId(patientID);
    }

    // Get documents from a department
    @GetMapping("/by-department/{departmentID}")
    public List<ArchiveDocument> getDocumentsByDepartmentId(
            @PathVariable("departmentID") int departmentID) {

        return documentService.getDocumentsByDepartmentId(departmentID);
    }

    // Get documents of a particular type
    @GetMapping("/by-document-type/{documentTypeID}")
    public List<ArchiveDocument> getDocumentsByDocumentTypeId(
            @PathVariable("documentTypeID") int documentTypeID) {

        return documentService.getDocumentsByDocumentTypeId(documentTypeID);
    }

    // Search documents by title
    @GetMapping("/search")
    public List<ArchiveDocument> searchDocumentsByTitle(
            @RequestParam("title") String title) {

        return documentService.searchDocumentsByTitle(title);
    }

    // Create document details
    @PostMapping
    public ResponseEntity<ArchiveDocument> createDocument(
            @RequestBody ArchiveDocument document,
            Principal principal) {

        User actor = getLoggedInUser(principal);

        if (document.getDocumentID() != 0) {
            throw new ResponseStatusException(
                    BAD_REQUEST,
                    "Leave document ID as zero when creating a document."
            );
        }

        document.setUploadedBy(actor.getUserID());
        document.setUploadDate(null);

        ArchiveDocument savedDocument = saveValidatedDocument(document);

        recordDocumentAction(
                actor.getUserID(),
                savedDocument.getDocumentID(),
                "CREATE",
                "Created document details."
        );

        URI location = URI.create(
                "/api/documents/" + savedDocument.getDocumentID()
        );

        return ResponseEntity.created(location).body(savedDocument);
    }

    // Update existing document details
    @PutMapping("/{documentID}")
    public ResponseEntity<ArchiveDocument> updateDocument(
            @PathVariable("documentID") int documentID,
            @RequestBody ArchiveDocument document,
            Principal principal) {

        User actor = getLoggedInUser(principal);

        if (document.getDocumentID() != 0
                && document.getDocumentID() != documentID) {
            throw new ResponseStatusException(
                    BAD_REQUEST,
                    "Document ID in the body must match the URL or be zero."
            );
        }

        ArchiveDocument existingDocument = documentService
                .getDocumentById(documentID)
                .orElse(null);

        if (existingDocument == null) {
            return ResponseEntity.notFound().build();
        }

        document.setDocumentID(documentID);

        // Preserve the original uploader and upload date
        document.setUploadDate(existingDocument.getUploadDate());
        document.setUploadedBy(existingDocument.getUploadedBy());

        ArchiveDocument savedDocument = saveValidatedDocument(document);

        recordDocumentAction(
                actor.getUserID(),
                savedDocument.getDocumentID(),
                "UPDATE",
                "Updated document details."
        );

        return ResponseEntity.ok(savedDocument);
    }

    // Delete document details
    @DeleteMapping("/{documentID}")
    public ResponseEntity<Void> deleteDocument(
            @PathVariable("documentID") int documentID,
            Principal principal) {

        User actor = getLoggedInUser(principal);

        if (documentService.getDocumentById(documentID).isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        documentService.deleteDocument(documentID);

        recordDocumentAction(
                actor.getUserID(),
                documentID,
                "DELETE",
                "Deleted document details."
        );

        return ResponseEntity.noContent().build();
    }

    // Find the user performing the current action
    private User getLoggedInUser(Principal principal) {

        if (principal == null) {
            throw new ResponseStatusException(
                    UNAUTHORIZED,
                    "Login is required."
            );
        }

        return userService.getUserByUsername(principal.getName())
                .orElseThrow(() -> new ResponseStatusException(
                        UNAUTHORIZED,
                        "Please log in again."
                ));
    }

    // Record an action without copying document contents into the log
    private void recordDocumentAction(
            int userID,
            int documentID,
            String action,
            String description) {

        Auditlog auditLog = new Auditlog();
        auditLog.setUserID(userID);
        auditLog.setDocumentID(documentID);
        auditLog.setAction(action);
        auditLog.setActionDescription(description);

        auditLogService.saveAuditLog(auditLog);
    }

    // Convert validation failures into a Bad Request response
    private ArchiveDocument saveValidatedDocument(ArchiveDocument document) {

        try {
            return documentService.saveDocument(document);
        } catch (IllegalArgumentException exception) {
            throw new ResponseStatusException(
                    BAD_REQUEST,
                    exception.getMessage()
            );
        }
    }
}
