package com.hospitalarchive.hospitalarchivebackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalarchivebackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(HospitalarchivebackendApplication.class, args);
    }

}
