package com.hospitalarchive.hospitalarchivebackend.service;

import com.hospitalarchive.hospitalarchivebackend.dto.UploadDocumentRequest;
import com.hospitalarchive.hospitalarchivebackend.model.ArchiveDocument;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Service
public class DocumentUploadService {

    private final FileStorageService fileStorageService;
    private final DocumentService documentService;

    // Constructor
    public DocumentUploadService(
            FileStorageService fileStorageService,
            DocumentService documentService) {

        this.fileStorageService = fileStorageService;
        this.documentService = documentService;
    }

    // Store a PDF and save its document details
    public ArchiveDocument uploadDocument(
            UploadDocumentRequest request,
            MultipartFile file,
            int uploaderID) throws IOException {

        if (request == null) {
            throw new IllegalArgumentException(
                    "Document details are required."
            );
        }

        if (uploaderID <= 0) {
            throw new IllegalArgumentException(
                    "A positive uploader user ID is required."
            );
        }

        String storedFilename = fileStorageService.storePdf(file);

        try {
            ArchiveDocument document = new ArchiveDocument();

            document.setPatientID(request.getPatientID());
            document.setDocumentTypeID(request.getDocumentTypeID());
            document.setDepartmentID(request.getDepartmentID());
            document.setDocumentTitle(request.getDocumentTitle());
            document.setUploadedBy(uploaderID);

            // Use the generated filename rather than a client-supplied path
            document.setFileName(storedFilename);
            document.setFilePath(storedFilename);
            document.setFileFormat("pdf");

            // Existing validation checks the details and related records
            return documentService.saveDocument(document);

        } catch (RuntimeException exception) {

            // Remove the unused PDF when saving document details fails
            try {
                fileStorageService.deleteStoredFile(storedFilename);
            } catch (IOException | RuntimeException cleanupException) {
                exception.addSuppressed(cleanupException);
            }

            throw exception;
        }
    }
}