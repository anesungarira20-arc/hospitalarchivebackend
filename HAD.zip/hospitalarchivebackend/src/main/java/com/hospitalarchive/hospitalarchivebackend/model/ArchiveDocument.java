package com.hospitalarchive.hospitalarchivebackend.model;

import java.time.LocalDateTime;

public class ArchiveDocument {

    private int documentID;
    private int patientID;
    private int documentTypeID;
    private int departmentID;
    private int uploadedBy;

    private String documentTitle;
    private String fileName;
    private String filePath;
    private String fileFormat;

    private LocalDateTime uploadDate;

    public ArchiveDocument() {

    }

    public ArchiveDocument (int documentID,int patientID,int documentTypeID,
                            int departmentID,int uploadedBy,String documentTitle,
                            String fileName, String filePath,String fileFormat) {

        this.documentID = documentID;
        this.patientID = patientID;
        this.documentTypeID = documentTypeID;
        this.departmentID = departmentID;
        this.uploadedBy = uploadedBy;
        this.documentTitle = documentTitle;
        this.fileName = fileName;
        this.filePath = filePath;
        this.fileFormat = fileFormat;
        this.uploadDate = LocalDateTime.now();

    }

    public int getDocumentID() {
        return documentID;
    }

    public void setDocumentID(int documentID) {
        this.documentID = documentID;
    }

    public int getPatientID() {
        return patientID;
    }

    public void setPatientID(int patientID) {
        this.patientID = patientID;
    }

    public int getDocumentTypeID() {
        return documentTypeID;
    }

    public void setDocumentTypeID(int documentTypeID) {
        this.documentTypeID = documentTypeID;
    }

    public int getDepartmentID() {
        return departmentID;
    }

    public void setDepartmentID(int departmentID) {
        this.departmentID = departmentID;
    }

    public int getUploadedBy() {
        return uploadedBy;
    }

    public void setUploadedBy(int uploadedBy) {
        this.uploadedBy = uploadedBy;
    }

    public String getDocumentTitle() {
        return documentTitle;
    }

    public void setDocumentTitle(String documentTitle) {
        this.documentTitle = documentTitle;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getFileFormat() {
        return fileFormat;
    }

    public void setFileFormat(String fileFormat) {
        this.fileFormat = fileFormat;
    }

    public LocalDateTime getUploadDate() {
        return uploadDate;
    }

    public void setUploadDate(LocalDateTime uploadDate) {
        this.uploadDate = uploadDate;
    }

    @Override
    public String toString() {
        return documentTitle;
    }
}

