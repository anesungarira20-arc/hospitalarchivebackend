package com.hospitalarchive.hospitalarchivebackend.repository;

import com.hospitalarchive.hospitalarchivebackend.model.Auditlog;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class InMemoryAuditLogRepository implements AuditLogRepository {

    private final Map<Integer, Auditlog> auditLogs = new LinkedHashMap<>();
    private int nextLogID = 1;

    // Create a new audit log
    @Override
    public synchronized Auditlog save(Auditlog auditLog) {

        if (auditLog == null) {
            throw new IllegalArgumentException("Audit log cannot be null.");
        }

        // Existing logs cannot be overwritten
        if (auditLog.getLogID() != 0) {
            throw new IllegalArgumentException(
                    "Log ID must be zero when creating an audit log."
            );
        }

        Auditlog storedLog = copyAuditLog(auditLog);
        storedLog.setLogID(nextLogID++);

        auditLogs.put(storedLog.getLogID(), storedLog);

        return copyAuditLog(storedLog);
    }

    // Find an audit log by ID
    @Override
    public synchronized Optional<Auditlog> findById(int logID) {

        Auditlog auditLog = auditLogs.get(logID);

        if (auditLog == null) {
            return Optional.empty();
        }

        return Optional.of(copyAuditLog(auditLog));
    }

    // Get all audit logs
    @Override
    public synchronized List<Auditlog> findAll() {

        List<Auditlog> results = new ArrayList<>();

        for (Auditlog auditLog : auditLogs.values()) {
            results.add(copyAuditLog(auditLog));
        }

        return results;
    }

    // Get audit logs for a user
    @Override
    public synchronized List<Auditlog> findByUserID(int userID) {

        List<Auditlog> results = new ArrayList<>();

        for (Auditlog auditLog : auditLogs.values()) {
            if (auditLog.getUserID() == userID) {
                results.add(copyAuditLog(auditLog));
            }
        }

        return results;
    }

    // Get audit logs for a document
    @Override
    public synchronized List<Auditlog> findByDocumentID(int documentID) {

        List<Auditlog> results = new ArrayList<>();

        for (Auditlog auditLog : auditLogs.values()) {
            if (auditLog.getDocumentID() != null
                    && auditLog.getDocumentID() == documentID) {
                results.add(copyAuditLog(auditLog));
            }
        }

        return results;
    }

    // Return a copy to protect stored log details
    private Auditlog copyAuditLog(Auditlog auditLog) {
        return new Auditlog(
                auditLog.getLogID(),
                auditLog.getUserID(),
                auditLog.getDocumentID(),
                auditLog.getAction(),
                auditLog.getActionDescription(),
                auditLog.getActionDate()
        );
    }
}
