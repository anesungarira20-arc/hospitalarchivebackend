package com.hospitalarchive.hospitalarchivebackend.service;

import com.hospitalarchive.hospitalarchivebackend.model.Auditlog;
import com.hospitalarchive.hospitalarchivebackend.repository.AuditLogRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class AuditLogService {

    private final AuditLogRepository auditLogRepository;

    public AuditLogService(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    public Auditlog saveAuditLog(Auditlog auditLog) {

        if (auditLog == null) {
            throw new IllegalArgumentException("Audit log cannot be null.");
        }

        if (auditLog.getUserID() <= 0) {
            throw new IllegalArgumentException("A positive user ID is required.");
        }

        if (auditLog.getDocumentID() != null
                && auditLog.getDocumentID() <= 0) {
            throw new IllegalArgumentException("Document ID must be positive.");
        }

        if (auditLog.getAction() == null
                || auditLog.getAction().isBlank()) {
            throw new IllegalArgumentException("Action is required.");
        }

        if (auditLog.getActionDescription() == null
                || auditLog.getActionDescription().isBlank()) {
            throw new IllegalArgumentException("Action description is required.");
        }

        if (auditLog.getActionDate() == null) {
            auditLog.setActionDate(LocalDateTime.now());
        }

        return auditLogRepository.save(auditLog);
    }

    public Optional<Auditlog> getAuditLogById(int logID) {
        return auditLogRepository.findById(logID);
    }

    public List<Auditlog> getAllAuditLogs() {
        return auditLogRepository.findAll();
    }

    public List<Auditlog> getAuditLogsByUserId(int userID) {
        return auditLogRepository.findByUserID(userID);
    }

    public List<Auditlog> getAuditLogsByDocumentId(int documentID) {
        return auditLogRepository.findByDocumentID(documentID);
    }
}
