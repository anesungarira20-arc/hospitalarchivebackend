package com.hospitalarchive.hospitalarchivebackend.controller;

import com.hospitalarchive.hospitalarchivebackend.dto.CreateUserRequest;
import com.hospitalarchive.hospitalarchivebackend.dto.UpdateUserRoleRequest;
import com.hospitalarchive.hospitalarchivebackend.dto.UserResponse;
import com.hospitalarchive.hospitalarchivebackend.model.User;
import com.hospitalarchive.hospitalarchivebackend.service.UserService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.net.URI;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    // Constructor
    public UserController(UserService userService) {
        this.userService = userService;
    }

    // Create a user
    @PostMapping
    public ResponseEntity<UserResponse> createUser(
            @RequestBody CreateUserRequest request) {

        User user = new User();
        user.setFullName(request.getFullName());
        user.setUsername(request.getUsername());
        user.setPassword(request.getPassword());
        user.setEmail(request.getEmail());

        // Assign the initial role on the server
        user.setRole("READ_ONLY");

        User savedUser;

        try {
            savedUser = userService.saveUser(user);
        } catch (IllegalArgumentException exception) {
            throw new ResponseStatusException(
                    BAD_REQUEST,
                    exception.getMessage()
            );
        }

        URI location = URI.create(
                "/api/users/" + savedUser.getUserID()
        );

        return ResponseEntity.created(location)
                .body(new UserResponse(savedUser));
    }

    // Change a user's role; administrator access is enforced by SecurityConfig
    @PutMapping("/{userID}/role")
    public ResponseEntity<UserResponse> updateUserRole(
            @PathVariable("userID") int userID,
            @RequestBody UpdateUserRoleRequest request) {

        if (userService.getUserById(userID).isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        User updatedUser;

        try {
            updatedUser = userService.updateUserRole(
                    userID,
                    request.getRole()
            );
        } catch (IllegalArgumentException exception) {
            throw new ResponseStatusException(
                    BAD_REQUEST,
                    exception.getMessage()
            );
        }

        return ResponseEntity.ok(new UserResponse(updatedUser));
    }
}
