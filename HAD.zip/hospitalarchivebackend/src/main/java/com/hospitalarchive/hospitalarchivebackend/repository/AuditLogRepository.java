package com.hospitalarchive.hospitalarchivebackend.repository;

import com.hospitalarchive.hospitalarchivebackend.model.Auditlog;

import java.util.List;
import java.util.Optional;

public interface AuditLogRepository {

    Auditlog save(Auditlog auditLog);


    Optional<Auditlog> findById(int logID);

    List<Auditlog> findAll();


    List<Auditlog> findByUserID(int userID);

    List<Auditlog> findByDocumentID(int documentID);
}

