package com.hospitalarchive.hospitalarchivebackend.repository;

import com.hospitalarchive.hospitalarchivebackend.model.ArchiveDocument;

import java.util.List;
import java.util.Optional;


public interface DocumentRepository {

    ArchiveDocument save(ArchiveDocument document);

    Optional<ArchiveDocument> findById(int documentID);

    List<ArchiveDocument> findAll();

    List<ArchiveDocument> findByPatientID(int patientID);

    List<ArchiveDocument> findByDepartmentID(int departmentID);

    List<ArchiveDocument> findByDocumentTypeID(int documentTypeID);

    List<ArchiveDocument> findByDocumentTitleContaining(String title);

    void deleteById(int documentID);
}
