package com.hospitalarchive.hospitalarchivebackend.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.session.ChangeSessionIdAuthenticationStrategy;
import org.springframework.security.web.authentication.session.CompositeSessionAuthenticationStrategy;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
import org.springframework.security.web.context.DelegatingSecurityContextRepository;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.security.web.context.RequestAttributeSecurityContextRepository;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.security.web.csrf.CsrfAuthenticationStrategy;
import org.springframework.security.web.csrf.CsrfTokenRepository;
import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;
import com.hospitalarchive.hospitalarchivebackend.repository.UserRepository;
import org.springframework.security.web.access.intercept.AuthorizationFilter;
import java.util.List;
import jakarta.servlet.DispatcherType;

@Configuration
public class SecurityConfig {

    // Check login credentials using stored users and password hashes
    @Bean
    public AuthenticationManager authenticationManager(
            UserDetailsService userDetailsService,
            PasswordEncoder passwordEncoder) {

        DaoAuthenticationProvider provider =
                new DaoAuthenticationProvider(userDetailsService);

        provider.setPasswordEncoder(passwordEncoder);

        return new ProviderManager(provider);
    }

    // Store authentication for the current request and session
    @Bean
    public SecurityContextRepository securityContextRepository() {
        return new DelegatingSecurityContextRepository(
                new RequestAttributeSecurityContextRepository(),
                new HttpSessionSecurityContextRepository()
        );
    }

    // Store the CSRF token in the session
    @Bean
    public CsrfTokenRepository csrfTokenRepository() {
        return new HttpSessionCsrfTokenRepository();
    }

    // Refresh the session ID and clear the old CSRF token after login
    @Bean
    public SessionAuthenticationStrategy sessionAuthenticationStrategy(
            CsrfTokenRepository csrfTokenRepository) {

        return new CompositeSessionAuthenticationStrategy(List.of(
                new ChangeSessionIdAuthenticationStrategy(),
                new CsrfAuthenticationStrategy(csrfTokenRepository)
        ));
    }

    // Configure API access
    @Bean
    public SecurityFilterChain securityFilterChain(
            HttpSecurity http,
            SecurityContextRepository securityContextRepository,
            CsrfTokenRepository csrfTokenRepository,
            SessionAuthenticationStrategy sessionAuthenticationStrategy,
            UserRepository userRepository)
            throws Exception {

        http
                .securityContext(context -> context
                        .securityContextRepository(securityContextRepository)
                        .requireExplicitSave(true)
                )
                .sessionManagement(session -> session
                        .sessionAuthenticationStrategy(
                                sessionAuthenticationStrategy)
                )
                .csrf(csrf -> csrf
                        .csrfTokenRepository(csrfTokenRepository)
                )
                .authorizeHttpRequests(authorize -> authorize
// Allow Spring to return the original error response
                                .dispatcherTypeMatchers(DispatcherType.ERROR).permitAll()
                                // Allow users to log in without an existing session
                                .requestMatchers(
                                        HttpMethod.POST,
                                        "/api/auth/login"
                                ).permitAll()
                        // Public status and CSRF token endpoints
                        .requestMatchers(
                                HttpMethod.GET,
                                "/api/status",
                                "/api/auth/csrf"
                        ).permitAll()

                                .requestMatchers(
                                        HttpMethod.POST,
                                        "/api/patients",
                                        "/api/documents",
                                        "/api/documents/upload"
                                ).hasAnyRole("ADMIN", "ARCHIVE_STAFF"
                                )

                        // Logged-in users can log out
                        .requestMatchers(
                                HttpMethod.POST,
                                "/api/auth/logout"
                        ).authenticated()

                        // All three roles can read archive records
                        .requestMatchers(
                                HttpMethod.GET,
                                "/api/patients",
                                "/api/patients/**",
                                "/api/documents",
                                "/api/documents/**",
                                "/api/departments",
                                "/api/departments/**",
                                "/api/document-types",
                                "/api/document-types/**"
                        ).hasAnyRole("ADMIN", "ARCHIVE_STAFF", "READ_ONLY")

                        // Administrators and archive staff can create records
                        .requestMatchers(
                                HttpMethod.POST,
                                "/api/patients",
                                "/api/documents"
                        ).hasAnyRole("ADMIN", "ARCHIVE_STAFF")

                        // Administrators and archive staff can update records
                        .requestMatchers(
                                HttpMethod.PUT,
                                "/api/patients/*",
                                "/api/documents/*"
                        ).hasAnyRole("ADMIN", "ARCHIVE_STAFF")

                        // Only administrators can delete records
                        .requestMatchers(
                                HttpMethod.DELETE,
                                "/api/patients/*",
                                "/api/documents/*"
                        ).hasRole("ADMIN")

                        // Remaining lookup-management operations require an administrator
                        .requestMatchers(
                                "/api/departments",
                                "/api/departments/**",
                                "/api/document-types",
                                "/api/document-types/**"
                        ).hasRole("ADMIN")

                        // User management requires an administrator
                        .requestMatchers(
                                "/api/users",
                                "/api/users/**"
                        ).hasRole("ADMIN")
// Only administrators can read audit logs
                                .requestMatchers(
                                        HttpMethod.GET,
                                        "/api/audit-logs",
                                        "/api/audit-logs/**"
                                ).hasRole("ADMIN")

                        // Block endpoints without an explicit access rule
                        .anyRequest().denyAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/api/auth/logout")
                        .invalidateHttpSession(true)
                        .clearAuthentication(true)
                        .deleteCookies("JSESSIONID")
                        .logoutSuccessHandler((request, response, authentication) ->
                                response.setStatus(204))
                )
                .formLogin(form -> form.disable())
                .httpBasic(basic -> basic.disable())
                .requestCache(cache -> cache.disable())
                .exceptionHandling(exceptions -> exceptions
                        .authenticationEntryPoint((request, response, exception) ->
                                response.setStatus(401))
                        .accessDeniedHandler((request, response, exception) ->
                                response.setStatus(403))
                );

        http.addFilterBefore(
                new UserSessionValidationFilter(userRepository),
                AuthorizationFilter.class
        );
        return http.build();
    }
}