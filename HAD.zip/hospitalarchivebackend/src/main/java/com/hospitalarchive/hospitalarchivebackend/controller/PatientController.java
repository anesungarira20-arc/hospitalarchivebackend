package com.hospitalarchive.hospitalarchivebackend.controller;

import com.hospitalarchive.hospitalarchivebackend.model.Patient;
import com.hospitalarchive.hospitalarchivebackend.service.PatientService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.net.URI;
import java.util.List;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

@RestController
@RequestMapping("/api/patients")
public class PatientController {

    private final PatientService patientService;

    // Constructor
    public PatientController(PatientService patientService) {
        this.patientService = patientService;
    }

    // Get all patients
    @GetMapping
    public List<Patient> getAllPatients() {
        return patientService.getAllPatients();
    }

    // Find a patient by ID
    @GetMapping("/{patientID}")
    public ResponseEntity<Patient> getPatientById(
            @PathVariable("patientID") int patientID) {

        return patientService.getPatientById(patientID)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Find a patient by hospital number
    @GetMapping("/by-hospital-number")
    public ResponseEntity<Patient> getPatientByHospitalNumber(
            @RequestParam("hospitalNumber") String hospitalNumber) {

        return patientService.getPatientByHospitalNumber(hospitalNumber)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Create a patient
    @PostMapping
    public ResponseEntity<Patient> createPatient(
            @RequestBody Patient patient) {

        if (patient.getPatientID() != 0) {
            throw new ResponseStatusException(
                    BAD_REQUEST,
                    "Leave patient ID as zero when creating a patient."
            );
        }

        Patient savedPatient = saveValidatedPatient(patient);

        URI location = URI.create(
                "/api/patients/" + savedPatient.getPatientID()
        );

        return ResponseEntity.created(location).body(savedPatient);
    }

    // Update an existing patient
    @PutMapping("/{patientID}")
    public ResponseEntity<Patient> updatePatient(
            @PathVariable("patientID") int patientID,
            @RequestBody Patient patient) {

        if (patient.getPatientID() != 0
                && patient.getPatientID() != patientID) {
            throw new ResponseStatusException(
                    BAD_REQUEST,
                    "Patient ID in the body must match the URL or be zero."
            );
        }

        if (patientService.getPatientById(patientID).isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        patient.setPatientID(patientID);

        Patient savedPatient = saveValidatedPatient(patient);

        return ResponseEntity.ok(savedPatient);
    }

    // Delete an existing patient
    @DeleteMapping("/{patientID}")
    public ResponseEntity<Void> deletePatient(
            @PathVariable("patientID") int patientID) {

        if (patientService.getPatientById(patientID).isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        try {
            patientService.deletePatient(patientID);
        } catch (IllegalStateException exception) {
            throw new ResponseStatusException(
                    org.springframework.http.HttpStatus.CONFLICT,
                    exception.getMessage()
            );
        }

        return ResponseEntity.noContent().build();
    }

    // Convert validation failures into a Bad Request response
    private Patient saveValidatedPatient(Patient patient) {

        try {
            return patientService.savePatient(patient);
        } catch (IllegalArgumentException exception) {
            throw new ResponseStatusException(
                    BAD_REQUEST,
                    exception.getMessage()
            );
        }
    }
}
