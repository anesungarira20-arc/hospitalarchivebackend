package com.hospitalarchive.hospitalarchivebackend.repository;

import com.hospitalarchive.hospitalarchivebackend.model.Department;

import java.util.List;
import java.util.Optional;

public interface DepartmentRepository {

    Department save(Department department);

    Optional<Department> findById(int departmentID);

    Optional<Department> findByDepartmentName(String departmentName);

    List<Department> findAll();

    boolean existsByDepartmentName(String departmentName);

    void deleteById(int departmentID);
}
