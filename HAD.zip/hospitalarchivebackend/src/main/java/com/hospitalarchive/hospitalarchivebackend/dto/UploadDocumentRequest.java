package com.hospitalarchive.hospitalarchivebackend.dto;

public class UploadDocumentRequest {

    private int patientID;
    private int documentTypeID;
    private int departmentID;
    private String documentTitle;

    public UploadDocumentRequest() {
    }

    public int getPatientID() {
        return patientID;
    }

    public void setPatientID(int patientID) {
        this.patientID = patientID;
    }

    public int getDocumentTypeID() {
        return documentTypeID;
    }

    public void setDocumentTypeID(int documentTypeID) {
        this.documentTypeID = documentTypeID;
    }

    public int getDepartmentID() {
        return departmentID;
    }

    public void setDepartmentID(int departmentID) {
        this.departmentID = departmentID;
    }

    public String getDocumentTitle() {
        return documentTitle;
    }

    public void setDocumentTitle(String documentTitle) {
        this.documentTitle = documentTitle;
    }
}
