package com.hospitalarchive.hospitalarchivebackend.model;

import java.time.LocalDateTime;

public class Auditlog {

    private int logID;
    private int userID;
    private Integer documentID;
    private String action;
    private String actionDescription;
    private LocalDateTime actionDate;

    public Auditlog() {
    }

    public Auditlog(int logID,
                    int userID,
                    Integer documentID,
                    String action,
                    String actionDescription,
                    LocalDateTime actionDate) {

        this.logID = logID;
        this.userID = userID;
        this.documentID = documentID;
        this.action = action;
        this.actionDescription = actionDescription;
        this.actionDate = actionDate;
    }

    public int getLogID() {
        return logID;
    }

    public void setLogID(int logID) {
        this.logID = logID;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public Integer getDocumentID() {
        return documentID;
    }

    public void setDocumentID(Integer documentID) {
        this.documentID = documentID;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getActionDescription() {
        return actionDescription;
    }

    public void setActionDescription(String actionDescription) {
        this.actionDescription = actionDescription;
    }

    public LocalDateTime getActionDate() {
        return actionDate;
    }

    public void setActionDate(LocalDateTime actionDate) {
        this.actionDate = actionDate;
    }
}
