package com.hospitalarchive.hospitalarchivebackend.service;

import com.hospitalarchive.hospitalarchivebackend.model.ArchiveDocument;
import com.hospitalarchive.hospitalarchivebackend.repository.DocumentRepository;
import com.hospitalarchive.hospitalarchivebackend.repository.PatientRepository;
import com.hospitalarchive.hospitalarchivebackend.repository.DepartmentRepository;
import com.hospitalarchive.hospitalarchivebackend.repository.DocumentTypeRepository;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class DocumentService {

    private final DocumentRepository documentRepository;
    private final PatientRepository patientRepository;
    private final DepartmentRepository departmentRepository;
    private final DocumentTypeRepository documentTypeRepository;

    // Constructor
    public DocumentService(
            DocumentRepository documentRepository,
            PatientRepository patientRepository,
            DepartmentRepository departmentRepository,
            DocumentTypeRepository documentTypeRepository) {

        this.documentRepository = documentRepository;
        this.patientRepository = patientRepository;
        this.departmentRepository = departmentRepository;
        this.documentTypeRepository = documentTypeRepository;
    }

    // Add or update document details
    public ArchiveDocument saveDocument(ArchiveDocument document) {

        if (document == null) {
            throw new IllegalArgumentException("Document cannot be null.");
        }

        if (document.getDocumentTitle() == null
                || document.getDocumentTitle().isBlank()) {
            throw new IllegalArgumentException("Document title is required.");
        }

        if (document.getPatientID() <= 0) {
            throw new IllegalArgumentException("A positive patient ID is required.");
        }

        if (document.getDocumentTypeID() <= 0) {
            throw new IllegalArgumentException("A positive document type ID is required.");
        }

        if (document.getDepartmentID() <= 0) {
            throw new IllegalArgumentException("A positive department ID is required.");
        }

        if (document.getUploadedBy() <= 0) {
            throw new IllegalArgumentException("A positive uploader user ID is required.");
        }

        if (document.getFileName() == null
                || document.getFileName().isBlank()) {
            throw new IllegalArgumentException("File name is required.");
        }

        if (document.getFilePath() == null
                || document.getFilePath().isBlank()) {
            throw new IllegalArgumentException("File path is required.");
        }

        if (document.getFileFormat() == null
                || document.getFileFormat().isBlank()) {
            throw new IllegalArgumentException("File format is required.");
        }

        // Check that the related records exist
        if (patientRepository.findById(document.getPatientID()).isEmpty()) {
            throw new IllegalArgumentException("Patient does not exist.");
        }

        if (departmentRepository.findById(document.getDepartmentID()).isEmpty()) {
            throw new IllegalArgumentException("Department does not exist.");
        }

        if (documentTypeRepository.findById(
                document.getDocumentTypeID()).isEmpty()) {
            throw new IllegalArgumentException("Document type does not exist.");
        }

        // Set the upload date if it has not been provided
        if (document.getUploadDate() == null) {
            document.setUploadDate(LocalDateTime.now());
        }

        return documentRepository.save(document);
    }

    // Find a document by ID
    public Optional<ArchiveDocument> getDocumentById(int documentID) {
        return documentRepository.findById(documentID);
    }

    // Get all documents
    public List<ArchiveDocument> getAllDocuments() {
        return documentRepository.findAll();
    }

    // Get documents belonging to a patient
    public List<ArchiveDocument> getDocumentsByPatientId(int patientID) {
        return documentRepository.findByPatientID(patientID);
    }

    // Get documents from a department
    public List<ArchiveDocument> getDocumentsByDepartmentId(int departmentID) {
        return documentRepository.findByDepartmentID(departmentID);
    }

    // Get documents of a particular type
    public List<ArchiveDocument> getDocumentsByDocumentTypeId(int documentTypeID) {
        return documentRepository.findByDocumentTypeID(documentTypeID);
    }

    // Search documents by title
    public List<ArchiveDocument> searchDocumentsByTitle(String title) {

        if (title == null || title.isBlank()) {
            return List.of();
        }

        return documentRepository.findByDocumentTitleContaining(title);
    }

    // Delete document details
    public void deleteDocument(int documentID) {
        documentRepository.deleteById(documentID);
    }
}


