package com.hospitalarchive.hospitalarchivebackend.service;

import com.hospitalarchive.hospitalarchivebackend.model.Department;
import com.hospitalarchive.hospitalarchivebackend.repository.DepartmentRepository;
import com.hospitalarchive.hospitalarchivebackend.repository.DocumentRepository;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DepartmentService {

    private final DepartmentRepository departmentRepository;
    private final DocumentRepository documentRepository;

    // Constructor
    public DepartmentService(
            DepartmentRepository departmentRepository,
            DocumentRepository documentRepository) {

        this.departmentRepository = departmentRepository;
        this.documentRepository = documentRepository;
    }

    // Add or update a department
    public Department saveDepartment(Department department) {

        if (department == null) {
            throw new IllegalArgumentException("Department cannot be null.");
        }

        if (department.getDepartmentName() == null
                || department.getDepartmentName().isBlank()) {
            throw new IllegalArgumentException("Department name is required.");
        }

        return departmentRepository.save(department);
    }

    // Find a department by ID
    public Optional<Department> getDepartmentById(int departmentID) {
        return departmentRepository.findById(departmentID);
    }

    // Find a department by name
    public Optional<Department> getDepartmentByName(String departmentName) {

        if (departmentName == null || departmentName.isBlank()) {
            return Optional.empty();
        }

        return departmentRepository.findByDepartmentName(departmentName);
    }

    // Get all departments
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    // Check whether a department name exists
    public boolean existsByDepartmentName(String departmentName) {

        if (departmentName == null || departmentName.isBlank()) {
            return false;
        }

        return departmentRepository.existsByDepartmentName(departmentName);
    }

    // Delete a department only when no documents reference it
    public void deleteDepartment(int departmentID) {

        if (!documentRepository.findByDepartmentID(departmentID).isEmpty()) {
            throw new IllegalStateException(
                    "Cannot delete a department that has linked documents."
            );
        }

        departmentRepository.deleteById(departmentID);
    }
}